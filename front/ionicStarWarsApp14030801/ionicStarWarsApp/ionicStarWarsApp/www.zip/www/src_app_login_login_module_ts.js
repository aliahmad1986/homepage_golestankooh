"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_login_login_module_ts"],{

/***/ 45393:
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageRoutingModule": () => (/* binding */ LoginPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page */ 66825);




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_0__.LoginPage
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ 80107:
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPageModule": () => (/* binding */ LoginPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login-routing.module */ 45393);
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page */ 66825);







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _login_routing_module__WEBPACK_IMPORTED_MODULE_0__.LoginPageRoutingModule
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_1__.LoginPage]
    })
], LoginPageModule);



/***/ }),

/***/ 66825:
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LoginPage": () => (/* binding */ LoginPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./login.page.html?ngResource */ 41729);
/* harmony import */ var _login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./login.page.scss?ngResource */ 87047);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);






let LoginPage = class LoginPage {
    constructor(navCtrl, title) {
        this.navCtrl = navCtrl;
        this.title = title;
        title.setTitle("ثبت نام");
    }
    ngOnInit() {
    }
    exitToHome() {
        this.navCtrl.navigateForward('/home');
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__.Title }
];
LoginPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-login',
        template: _login_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_login_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], LoginPage);



/***/ }),

/***/ 87047:
/*!**************************************************!*\
  !*** ./src/app/login/login.page.scss?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = ".exit-btn {\n  transform: scaleX(-1);\n}\n\ndiv {\n  font-family: Ray;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLHFCQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQkFBQTtBQUNGIiwiZmlsZSI6ImxvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5leGl0LWJ0bntcclxuIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZVgoLTEpO1xyXG4gIHRyYW5zZm9ybTogc2NhbGVYKC0xKTtcclxufVxyXG5cclxuZGl2e1xyXG4gIGZvbnQtZmFtaWx5OiBSYXk7XHJcbn1cclxuIl19 */";

/***/ }),

/***/ 41729:
/*!**************************************************!*\
  !*** ./src/app/login/login.page.html?ngResource ***!
  \**************************************************/
/***/ ((module) => {

module.exports = "<ion-content color=\"blue\">\n  <!-- <img src=\"assets\\imges\\bg login.png\"> -->\n<ion-button color=\"danger\" (click)=\"exitToHome()\" style=\"margin: 20px;\" title=\"بازگشت به صفحه ی نخست\">\n  <ion-icon class=\"exit-btn\" name=\"exit\"></ion-icon>\n</ion-button>\n\n\n<div>\n<h1 style=\"text-align: center; color: #002540;\">ثـــبت نـــام</h1>\n</div>\n\n<!-- <div style=\"text-align: center;\">\n  <ion-card>\n  <div style=\"margin-top: 50px;\">\n    <ion-label>\n      <input style=\"border-radius: 7%;\">\n    </ion-label>نام و نام خانوادگی\n  </div>\n  <div></div>\n  <div></div>\n  <div></div>\n\n</ion-card>\n</div> -->\n<form style=\"\" >\n<div style=\"display: flex; justify-content: center;\">\n  <ion-card style=\"padding: 25px; border-radius: 20px;\n  border-color: #7e8181;\n  box-shadow: 1px 1px 1px 2px #b6b7b7; max-width:800px;\">\n<div class=\"form-group\" dir=\"rtl\" >\n  <div >\n   <label class=\"my-2\" style=\"color: #002540;\">نام و نام خانوادگی*</label>\n    <div class=\"row\"style=\"text-align: center;\">\n      <div class=\"\"style=\"text-align: center; width: 700px;\">\n       <input type=\"text\" class=\"form-control\"  >\n      </div>\n   </div>\n  </div>\n</div>\n<div class=\"form-group\" dir=\"rtl\" >\n  <div >\n   <label class=\"my-2\" style=\"color: #002540;\">شماره همراه*</label>\n    <div class=\"row\"style=\"text-align: center;\">\n      <div class=\"col-\"style=\"text-align: center;width: 700px;\">\n       <input type=\"text\" placeholder=\"09\" class=\"form-control\"  >\n      </div>\n   </div>\n  </div>\n</div>\n<div class=\"form-group\" dir=\"rtl\" >\n  <div >\n   <label class=\"my-2\" style=\"color: #002540;\">ایدی اینستاگرام</label>\n    <div class=\"row\"style=\"text-align: center;\">\n      <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n       <input type=\"text\" placeholder=\"اختیاری\" class=\"form-control\"  >\n      </div>\n   </div>\n  </div>\n</div>\n<div class=\"form-group\" dir=\"rtl\" >\n  <div >\n   <label class=\"my-2\" style=\"color: #002540;\">ایمیل</label>\n    <div class=\"row\"style=\"text-align: center;\">\n      <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n       <input type=\"text\" placeholder=\"اختیاری\" class=\"form-control\"  >\n      </div>\n   </div>\n  </div>\n</div>\n</ion-card>\n</div>\n</form>\n\n\n\n<div style=\"text-align: center;\">\n  <ion-button color=\"danger\"style=\"margin-right: 20px;\" (click)=\"exitToHome()\">\n    <ion-icon name=\"close-outline\" ></ion-icon>\n        لغو</ion-button>\n  <ion-button color=\"success\">\n    <ion-icon name=\"checkmark-outline\"></ion-icon>\n    ثبت</ion-button>\n\n</div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_login_login_module_ts.js.map