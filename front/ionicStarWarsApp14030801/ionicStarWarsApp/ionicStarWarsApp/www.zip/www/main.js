(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["main"],{

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": () => (/* binding */ AppRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 60124);



const routes = [
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_mainfooter_mainfooter_module_ts-src_app_toolbar_toolbar_module_ts"), __webpack_require__.e("src_app_home_home_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./home/home.module */ 3467)).then(m => m.HomePageModule)
    },
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'facilities',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_mainfooter_mainfooter_module_ts-src_app_toolbar_toolbar_module_ts"), __webpack_require__.e("src_app_facilities_facilities_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./facilities/facilities.module */ 16682)).then(m => m.FacilitiesPageModule)
    },
    {
        path: 'login',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_login_login_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./login/login.module */ 80107)).then(m => m.LoginPageModule)
    },
    {
        path: 'deli',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_mainfooter_mainfooter_module_ts-src_app_toolbar_toolbar_module_ts"), __webpack_require__.e("src_app_deli_deli_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./deli/deli.module */ 95881)).then(m => m.DeliPageModule)
    },
    {
        path: 'gallery',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_gallery_gallery_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./gallery/gallery.module */ 18632)).then(m => m.GalleryPageModule)
    },
    {
        path: 'customer-club',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_customer-club_customer-club_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./customer-club/customer-club.module */ 31203)).then(m => m.CustomerClubPageModule)
    },
    {
        path: 'comment',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_comment_comment_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./comment/comment.module */ 29007)).then(m => m.CommentPageModule)
    },
    {
        path: 'mainfooter',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_mainfooter_mainfooter_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./mainfooter/mainfooter.module */ 20890)).then(m => m.MainfooterCModule)
    },
    {
        path: 'deli-gallery',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_deli_deli-gallery_deli-gallery_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./deli/deli-gallery/deli-gallery.module */ 11863)).then(m => m.DeliGalleryPageModule)
    },
    {
        path: 'vrfyreservation',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_vrfyreservation_vrfyreservation_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./vrfyreservation/vrfyreservation.module */ 41495)).then(m => m.VrfyreservationPageModule)
    },
    {
        path: 'landing',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_landing_landing_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./landing/landing.module */ 68721)).then(m => m.LandingPageModule)
    },
    {
        path: 'reserve',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("default-src_app_mainfooter_mainfooter_module_ts-src_app_toolbar_toolbar_module_ts"), __webpack_require__.e("src_app_reserve_reserve_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./reserve/reserve.module */ 20056)).then(m => m.ReservePageModule)
    },
    {
        path: 'suit101',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit101_suit101_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit101/suit101.module */ 47665)).then(m => m.Suit101PageModule)
    },
    {
        path: 'suit102',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit102_suit102_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit102/suit102.module */ 52828)).then(m => m.Suit102PageModule)
    },
    {
        path: 'suit103',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit103_suit103_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit103/suit103.module */ 9960)).then(m => m.Suit103PageModule)
    },
    {
        path: 'suit104',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit104_suit104_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit104/suit104.module */ 55252)).then(m => m.Suit104PageModule)
    },
    {
        path: 'suit105',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit105_suit105_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit105/suit105.module */ 67590)).then(m => m.Suit105PageModule)
    },
    {
        path: 'suit106',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit106_suit106_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit106/suit106.module */ 83941)).then(m => m.Suit106PageModule)
    },
    {
        path: 'suit107',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit107_suit107_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit107/suit107.module */ 8840)).then(m => m.Suit107PageModule)
    },
    {
        path: 'suit108',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit108_suit108_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit108/suit108.module */ 41978)).then(m => m.Suit108PageModule)
    },
    {
        path: 'suit109',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit109_suit109_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit109/suit109.module */ 82868)).then(m => m.Suit109PageModule)
    },
    {
        path: 'suit110',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit110_suit110_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit110/suit110.module */ 41910)).then(m => m.Suit110PageModule)
    },
    {
        path: 'suit111',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit111_suit111_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit111/suit111.module */ 33625)).then(m => m.Suit111PageModule)
    },
    {
        path: 'suit112',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit112_suit112_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit112/suit112.module */ 69099)).then(m => m.Suit112PageModule)
    },
    {
        path: 'suit114',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit114_suit114_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit114/suit114.module */ 51239)).then(m => m.Suit114PageModule)
    },
    {
        path: 'suit115',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit115_suit115_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit115/suit115.module */ 59399)).then(m => m.Suit115PageModule)
    },
    {
        path: 'suit116',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit116_suit116_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit116/suit116.module */ 79671)).then(m => m.Suit116PageModule)
    },
    {
        path: 'suit118',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit118_suit118_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit118/suit118.module */ 28376)).then(m => m.Suit118PageModule)
    },
    {
        path: 'suit119',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit119_suit119_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit119/suit119.module */ 7966)).then(m => m.Suit119PageModule)
    },
    {
        path: 'suit120',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit120_suit120_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit120/suit120.module */ 98152)).then(m => m.Suit120PageModule)
    },
    {
        path: 'suit123',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit123_suit123_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit123/suit123.module */ 69067)).then(m => m.Suit123PageModule)
    },
    {
        path: 'suit124',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit124_suit124_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit124/suit124.module */ 80153)).then(m => m.Suit124PageModule)
    },
    {
        path: 'suit127',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit127_suit127_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit127/suit127.module */ 45549)).then(m => m.Suit127PageModule)
    },
    {
        path: 'suit128',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit128_suit128_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit128/suit128.module */ 41134)).then(m => m.Suit128PageModule)
    },
    {
        path: 'suit130',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit130_suit130_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit130/suit130.module */ 12686)).then(m => m.Suit130PageModule)
    },
    {
        path: 'suit131',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit131_suit131_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit131/suit131.module */ 44334)).then(m => m.Suit131PageModule)
    },
    {
        path: 'suit132',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit132_suit132_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit132/suit132.module */ 8895)).then(m => m.Suit132PageModule)
    },
    {
        path: 'suit134',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit134_suit134_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit134/suit134.module */ 39875)).then(m => m.Suit134PageModule)
    },
    {
        path: 'suit113',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit113_suit113_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit113/suit113.module */ 20191)).then(m => m.Suit113PageModule)
    },
    {
        path: 'suit117',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit117_suit117_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit117/suit117.module */ 98177)).then(m => m.Suit117PageModule)
    },
    {
        path: 'suit129',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit129_suit129_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit129/suit129.module */ 15453)).then(m => m.Suit129PageModule)
    },
    {
        path: 'suit133',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit133_suit133_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit133/suit133.module */ 87274)).then(m => m.Suit133PageModule)
    },
    {
        path: 'suit122',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit122_suit122_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit122/suit122.module */ 36389)).then(m => m.Suit122PageModule)
    },
    {
        path: 'suit121',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit121_suit121_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit121/suit121.module */ 27513)).then(m => m.Suit121PageModule)
    },
    {
        path: 'suit125',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit125_suit125_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit125/suit125.module */ 87835)).then(m => m.Suit125PageModule)
    },
    {
        path: 'suit126',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_suit126_suit126_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./suit126/suit126.module */ 76487)).then(m => m.Suit126PageModule)
    },
    {
        path: 'karvansara204',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara204_karvansara204_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara204/karvansara204.module */ 83514)).then(m => m.karvansara204Module)
    },
    {
        path: 'karvansara205',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara205_karvansara205_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara205/karvansara205.module */ 68886)).then(m => m.karvansara205PageModule)
    },
    {
        path: 'karvansara206',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara206_karvansara206_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara206/karvansara206.module */ 69987)).then(m => m.karvansara206PageModule)
    },
    {
        path: 'karvansara207',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara207_karvansara207_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara207/karvansara207.module */ 55598)).then(m => m.karvansara207PageModule)
    },
    {
        path: 'karvansara209',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara209_karvansara209_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara209/karvansara209.module */ 27991)).then(m => m.karvansara209PageModule)
    },
    {
        path: 'karvansara212',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara212_karvansara212_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara212/karvansara212.module */ 59651)).then(m => m.karvansara212PageModule)
    },
    {
        path: 'karvansara214',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara214_karvansara214_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara214/karvansara214.module */ 27370)).then(m => m.karvansara214PageModule)
    },
    {
        path: 'karvansara215',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara215_karvansara215_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara215/karvansara215.module */ 56414)).then(m => m.karvansara215PageModule)
    },
    {
        path: 'karvansara216',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara216_karvansara216_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara216/karvansara216.module */ 95000)).then(m => m.karvansara216PageModule)
    },
    {
        path: 'karvansara201',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara201_karvansara201_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara201/karvansara201.module */ 24565)).then(m => m.karvansara201Module)
    },
    {
        path: 'karvansara210',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara210_karvansara210_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara210/karvansara210.module */ 83130)).then(m => m.karvansara210PageModule)
    },
    {
        path: 'karvansara211',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara211_karvansara211_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara211/karvansara211.module */ 99425)).then(m => m.karvansara211PageModule)
    },
    {
        path: 'karvansara217',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara217_karvansara217_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara217/karvansara217.module */ 97581)).then(m => m.karvansara217PageModule)
    },
    {
        path: 'karvansara208',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara208_karvansara208_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara208/karvansara208.module */ 68190)).then(m => m.karvansara208PageModule)
    },
    {
        path: 'karvansara213',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara213_karvansara213_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara213/karvansara213.module */ 96190)).then(m => m.karvansara213PageModule)
    },
    {
        path: 'karvansara202',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara202_karvansara202_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara202/karvansara202.module */ 66901)).then(m => m.karvansara201PageModule)
    },
    {
        path: 'karvansara203',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara203_karvansara203_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara203/karvansara203.module */ 56149)).then(m => m.karvansara203PageModule)
    },
    {
        path: 'karvansara219',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara219_karvansara219_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara219/karvansara219.module */ 86749)).then(m => m.karvansara219PageModule)
    },
    {
        path: 'karvansara220',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara220_karvansara220_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara220/karvansara220.module */ 79556)).then(m => m.karvansara220PageModule)
    },
    {
        path: 'karvansara218',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-dist_lib-wizard-panel_fesm2020_lib-wizard-panel_mjs"), __webpack_require__.e("src_app_karvansara218_karvansara218_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara218/karvansara218.module */ 94697)).then(m => m.karvansara218PageModule)
    },
    {
        path: 'suitsdoblex',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_suitsdoblex_suitsdoblex_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./suitsdoblex/suitsdoblex.module */ 86602)).then(m => m.SuitsdoblexPageModule)
    },
    {
        path: 'royalsuits2beddouble',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_royalsuits2beddouble_royalsuits2beddouble_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./royalsuits2beddouble/royalsuits2beddouble.module */ 51004)).then(m => m.Royalsuits2beddoublePageModule)
    },
    {
        path: 'royalsuits4bed',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_royalsuits4bed_royalsuits4bed_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./royalsuits4bed/royalsuits4bed.module */ 69374)).then(m => m.Royalsuits4bedPageModule)
    },
    {
        path: 'royalroomvip',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_royalroomvip_royalroomvip_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./royalroomvip/royalroomvip.module */ 96237)).then(m => m.RoyalroomvipPageModule)
    },
    {
        path: 'karvansaravip',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_karvansaravip_karvansaravip_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./karvansaravip/karvansaravip.module */ 85635)).then(m => m.KarvansaravipPageModule)
    },
    {
        path: 'karvansaradouble',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_karvansaradouble_karvansaradouble_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./karvansaradouble/karvansaradouble.module */ 88137)).then(m => m.KarvansaradoublePageModule)
    },
    {
        path: 'karvansaratowin',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_karvansaratowin_karvansaratowin_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./karvansaratowin/karvansaratowin.module */ 84069)).then(m => m.KarvansaratowinPageModule)
    },
    {
        path: 'karvansara3bed',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_karvansara3bed_karvansara3bed_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./karvansara3bed/karvansara3bed.module */ 10480)).then(m => m.Karvansara3bedPageModule)
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": () => (/* binding */ AppComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component.html?ngResource */ 33383);
/* harmony import */ var _app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss?ngResource */ 79259);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);






let AppComponent = class AppComponent {
    constructor(navCtrl, location) {
        this.navCtrl = navCtrl;
        this.location = location;
        this.selectedIndex = 0;
        this.appPages = [
            {
                title: 'Home',
                url: '/folder/Inbox',
                icon: 'play-circle-outline'
            },
            {
                title: 'Parallax',
                url: '/parallax',
                icon: 'play-circle-outline'
            },
            {
                title: 'Expandable',
                url: '/expandable',
                icon: 'play-circle-outline'
            }
        ];
        // history.pushState(null, null, window.location.href);
        // // check if back or forward button is pressed.
        // this.location.onPopState(() => {
        //     history.pushState(null, null, window.location.href);
        //     this.stepper.previous();
        // });
    }
    facilitiesCollection() {
        // this.router.navigate(['/facilities']);
        this.navCtrl.navigateForward('/facilities');
        // this.router.navigateByUrl('/facilities');
        // alert('2222222222222')
    }
    login() {
        alert('login');
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__.NavController },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_3__.LocationStrategy }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-root',
        template: _app_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_app_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], AppComponent);



/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": () => (/* binding */ AppModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/platform-browser/animations */ 37146);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var ionic4_rating__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ionic4-rating */ 19397);
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ 40287);
/* harmony import */ var ngx_lightbox__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ngx-lightbox */ 37991);













let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
        entryComponents: [],
        imports: [
            ionic4_rating__WEBPACK_IMPORTED_MODULE_2__.IonicRatingModule,
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__.BrowserModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_1__.AppRoutingModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_9__.HttpClientModule,
            ngx_lightbox__WEBPACK_IMPORTED_MODULE_4__.LightboxModule, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_10__.NoopAnimationsModule
        ],
        providers: [
            _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_3__.Geolocation,
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicRouteStrategy },
            { provide: _angular_common__WEBPACK_IMPORTED_MODULE_12__.LocationStrategy, useClass: _angular_common__WEBPACK_IMPORTED_MODULE_12__.HashLocationStrategy },
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_0__.AppComponent],
    })
], AppModule);



/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": () => (/* binding */ environment)
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    host: {
        apiurl: 'https://golestankooh.com/backend/public',
        api_key: 'cumjtobhwnhtormbdlbeixxhbduxmycv'
    }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 76057);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./ion-accordion_2.entry.js": [
		70079,
		"common",
		"node_modules_ionic_core_dist_esm_ion-accordion_2_entry_js"
	],
	"./ion-action-sheet.entry.js": [
		25593,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		13225,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		4812,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		86655,
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		44856,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		13059,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-breadcrumb_2.entry.js": [
		58648,
		"common",
		"node_modules_ionic_core_dist_esm_ion-breadcrumb_2_entry_js"
	],
	"./ion-button_2.entry.js": [
		98308,
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		44690,
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		64090,
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		36214,
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		69447,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime-button.entry.js": [
		17950,
		"default-node_modules_ionic_core_dist_esm_parse-17d9d367_js-node_modules_ionic_core_dist_esm_t-a480aa",
		"node_modules_ionic_core_dist_esm_ion-datetime-button_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		79689,
		"default-node_modules_ionic_core_dist_esm_parse-17d9d367_js-node_modules_ionic_core_dist_esm_t-a480aa",
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		18840,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		40749,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		69667,
		"common",
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		83288,
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		35473,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		53634,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		22855,
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		495,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		58737,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		99632,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-picker-column-internal.entry.js": [
		54446,
		"common",
		"node_modules_ionic_core_dist_esm_ion-picker-column-internal_entry_js"
	],
	"./ion-picker-internal.entry.js": [
		32275,
		"node_modules_ionic_core_dist_esm_ion-picker-internal_entry_js"
	],
	"./ion-popover.entry.js": [
		48050,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		18994,
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		23592,
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		35454,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		290,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		92666,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		64816,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45534,
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		94902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		91938,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		78179,
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		90668,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		61624,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		19989,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		28902,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		70199,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		48395,
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		96357,
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		38268,
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		15269,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		32875,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(() => {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(() => {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = () => (Object.keys(map));
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 79259:
/*!***********************************************!*\
  !*** ./src/app/app.component.scss?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = ".bg-toolbar {\n  width: 1500px;\n}\n\n.menu-item-style {\n  font-weight: bold;\n  color: #002540;\n  font-family: \"custom\";\n}\n\n.icon-color {\n  color: #002540;\n}\n\n.menu-logo {\n  width: 80px;\n  height: 80px;\n  margin-top: 5px;\n  margin-bottom: 5px;\n  justify-items: center !important;\n  justify-content: center !important;\n  text-align: center;\n}\n\n.logo-text-style {\n  width: 150px;\n}\n\n.menu-pages {\n  margin-top: -100px;\n}\n\n.menu-pages-card {\n  max-width: 800px;\n  margin-left: 0 auto;\n  height: 350px;\n  border-radius: 20px;\n  border-color: #7e8181;\n  box-shadow: 0px 1px 0px 1px #b6b7b7;\n}\n\n.logo-text {\n  text-align: end !important;\n  justify-content: end !important;\n  justify-items: end !important;\n}\n\n.home-detailes-style {\n  font-size: 13px;\n  margin-top: 0px;\n  display: flex;\n  list-style: none;\n  color: white;\n  text-align: center;\n  padding-right: 3px;\n  padding-left: 3px;\n  justify-items: center;\n  justify-content: center;\n  font-weight: bold;\n}\n\n.home-detailes-style:hover {\n  color: #002540;\n  background-color: white;\n  border: #002540;\n}\n\n.home-detailes-style1 {\n  background-color: #002540;\n  text-align: center;\n}\n\n.bashgah {\n  margin-right: 3px;\n}\n\n.Main-Pahe-Bottom {\n  width: 85%;\n  background-color: #002540;\n  object-fit: cover;\n  object-position: center;\n  margin-top: 30px;\n  border-radius: 20px;\n  max-width: 750px;\n  max-height: 270px;\n}\n\n.contactus-style1 {\n  vertical-align: text-bottom;\n  margin-top: 15px;\n  margin-left: 6px;\n  size: 15px;\n  border-radius: 15px;\n  width: 153px;\n  height: 20px;\n  color: white;\n  background-color: #002540;\n}\n\n.contactus-style {\n  vertical-align: text-bottom;\n  margin-top: 15px;\n  margin-left: 6px;\n  size: 15px;\n  border-radius: 15px;\n  width: 153px;\n  height: 20px;\n  color: white;\n  background-color: #002540;\n}\n\n.logotext-style2 {\n  text-align: right;\n  justify-content: end !important;\n  justify-items: end !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7QUFDSjs7QUFDRTtFQUVFLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLHFCQUFBO0FBQ0o7O0FBQ0U7RUFDRSxjQUFBO0FBRUo7O0FBQUU7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdDQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtBQUdKOztBQURFO0VBQ0UsWUFBQTtBQUlKOztBQURFO0VBQ0Usa0JBQUE7QUFJSjs7QUFNRTtFQUdFLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1DQUFBO0FBTEo7O0FBUUU7RUFDRSwwQkFBQTtFQUNBLCtCQUFBO0VBQ0EsNkJBQUE7QUFMSjs7QUFRRTtFQUNFLGVBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsdUJBQUE7RUFDQSxpQkFBQTtBQUxKOztBQVNFO0VBQ0UsY0FBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtBQU5KOztBQVFJO0VBQ0UseUJBQUE7RUFFQSxrQkFBQTtBQU5OOztBQU9NO0VBQ0UsaUJBQUE7QUFKUjs7QUFPTTtFQUNFLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0YsZ0JBQUE7RUFDRixpQkFBQTtBQUpKOztBQU1RO0VBQ0UsMkJBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFIVjs7QUFNVTtFQUNFLDJCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0FBSFo7O0FBT1k7RUFDRSxpQkFBQTtFQUNBLCtCQUFBO0VBQ0EsNkJBQUE7QUFKZCIsImZpbGUiOiJhcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmctdG9vbGJhcntcclxuICAgIHdpZHRoOiAxNTAwcHg7XHJcbiAgfVxyXG4gIC5tZW51LWl0ZW0tc3R5bGV7XHJcbiAgICAvLyBmb250LWZhbWlseTogO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBjb2xvcjogIzAwMjU0MDtcclxuICAgIGZvbnQtZmFtaWx5OiBcImN1c3RvbVwiOyBcclxuICB9XHJcbiAgLmljb24tY29sb3J7XHJcbiAgICBjb2xvcjogIzAwMjU0MDtcclxuICB9XHJcbiAgLm1lbnUtbG9nb3tcclxuICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAganVzdGlmeS1pdGVtczogY2VudGVyIWltcG9ydGFudDtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyIWltcG9ydGFudDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgfVxyXG4gIC5sb2dvLXRleHQtc3R5bGV7XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgfVxyXG5cclxuICAubWVudS1wYWdlc3tcclxuICAgIG1hcmdpbi10b3A6IC0xMDBweDtcclxuICAgIC8vIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAvLyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAvLyBkaXNwbGF5OmlubGluZS1ibG9jaztcclxuICAvLyBtaW4td2lkdGg6ODAwcHg7XHJcbiAgLy8gbWF4LXdpZHRoOjgwMHB4O1xyXG4gIC8vIG1hcmdpbi1sZWZ0OiAwIGF1dG87XHJcbiAgXHJcbiAgXHJcbiAgfVxyXG4gIC5tZW51LXBhZ2VzLWNhcmR7XHJcbiAgICAvLyBkaXNwbGF5OmlubGluZS1ibG9jaztcclxuICAgIC8vIG1pbi13aWR0aDo4MDBweDtcclxuICAgIG1heC13aWR0aDo4MDBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAwIGF1dG87XHJcbiAgICBoZWlnaHQ6IDM1MHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIGJvcmRlci1jb2xvcjogIzdlODE4MTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxcHggMHB4IDFweCAjYjZiN2I3O1xyXG4gIH1cclxuICBcclxuICAubG9nby10ZXh0e1xyXG4gICAgdGV4dC1hbGlnbjogZW5kIWltcG9ydGFudDtcclxuICAgIGp1c3RpZnktY29udGVudDogZW5kIWltcG9ydGFudDtcclxuICAgIGp1c3RpZnktaXRlbXM6IGVuZCFpbXBvcnRhbnQ7XHJcbiAgXHJcbiAgfVxyXG4gIC5ob21lLWRldGFpbGVzLXN0eWxle1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgbWFyZ2luLXRvcDogMHB4O1xyXG4gICAgZGlzcGxheTpmbGV4OyAgXHJcbiAgICBsaXN0LXN0eWxlOm5vbmU7XHJcbiAgICBjb2xvcjp3aGl0ZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgICBwYWRkaW5nLXJpZ2h0OiAzcHg7XHJcbiAgICBwYWRkaW5nLWxlZnQ6IDNweDtcclxuICAgIGp1c3RpZnktaXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgXHJcbiAgfVxyXG4gIFxyXG4gIC5ob21lLWRldGFpbGVzLXN0eWxlOmhvdmVye1xyXG4gICAgY29sb3I6ICMwMDI1NDA7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGJvcmRlcjogIzAwMjU0MDt9XHJcbiAgXHJcbiAgICAuaG9tZS1kZXRhaWxlcy1zdHlsZTF7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDI1NDA7XHJcbiAgICAgIC8vIHdpZHRoOiBhdXRvO1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7fVxyXG4gICAgICAuYmFzaGdhaHtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDNweDtcclxuICAgICAgfVxyXG4gIFxyXG4gICAgICAuTWFpbi1QYWhlLUJvdHRvbXtcclxuICAgICAgICB3aWR0aDogODUlO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDI1NDA7XHJcbiAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgICAgb2JqZWN0LXBvc2l0aW9uOiBjZW50ZXI7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgICBtYXgtd2lkdGg6IDc1MHB4O1xyXG4gICAgbWF4LWhlaWdodDogMjcwcHg7fVxyXG4gIFxyXG4gICAgICAgIC5jb250YWN0dXMtc3R5bGUxe1xyXG4gICAgICAgICAgdmVydGljYWwtYWxpZ246dGV4dC1ib3R0b20gO1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogMTVweDtcclxuICAgICAgICAgIG1hcmdpbi1sZWZ0OiA2cHg7XHJcbiAgICAgICAgICBzaXplOiAxNXB4O1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICAgICAgICAgIHdpZHRoOiAxNTNweDtcclxuICAgICAgICAgIGhlaWdodDogMjBweDtcclxuICAgICAgICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDI1NDA7fVxyXG4gIFxyXG4gIFxyXG4gICAgICAgICAgLmNvbnRhY3R1cy1zdHlsZXtcclxuICAgICAgICAgICAgdmVydGljYWwtYWxpZ246dGV4dC1ib3R0b20gO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogNnB4O1xyXG4gICAgICAgICAgICBzaXplOiAxNXB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgICAgICAgICB3aWR0aDogMTUzcHg7XHJcbiAgICAgICAgICAgIGhlaWdodDogMjBweDtcclxuICAgICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAyNTQwO1xyXG4gICAgICAgICAgfVxyXG4gIFxyXG4gIFxyXG4gICAgICAgICAgICAubG9nb3RleHQtc3R5bGUye1xyXG4gICAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogZW5kIWltcG9ydGFudDtcclxuICAgICAgICAgICAgICBqdXN0aWZ5LWl0ZW1zOiBlbmQhaW1wb3J0YW50O31cclxuICAgICAgICAgXHJcbiAgICAgICAgIFxyXG4gICAgICAgXHJcbiAgXHJcbiAgIl19 */";

/***/ }),

/***/ 33383:
/*!***********************************************!*\
  !*** ./src/app/app.component.html?ngResource ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = "<ion-app>\n\n  <ion-router-outlet></ion-router-outlet>\n</ion-app>\n\n\n<!-- <ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"overlay\">\n      <ion-content>\n              <ion-header>\n          <ion-item class=\"transparent ion-text-center\" lines=\"none\">\n            <ion-label class=\"ion-text-left ion-padding-top\">\n                <h1 class=\"text-size-xl text-color-light ion-text-wrap\">Atom Ionic 6 Freebie Theme</h1>\n                <p class=\" text-color-light text-size-md ion-text-wrap\">\n                  Find quality code with a beautiful screen, this is a freebie for you!\n                </p>\n                <ion-button href=\"https://devspush.com/\" target=\"_blank\" size=\"default\"\n                class=\"default-button color-primary box-shadow ion-margin-top\">\n                Purchase Now\n              </ion-button>\n            </ion-label>\n          </ion-item>\n      </ion-header>\n\n        <ion-list id=\"inbox-list\">\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\n            <ion-item lines=\"none\" class=\"transparent\" (click)=\"selectedIndex = i\" routerDirection=\"root\" [routerLink]=\"[p.url]\" lines=\"none\" detail=\"false\" [class.selected]=\"selectedIndex == i\">\n              <ion-label>\n               <p class=\"text-size-md font-regular text-color-light\">{{ p.title }}</p>\n             </ion-label>\n               <ion-icon slot=\"end\" class=\"icon-color-light\"  [name]=\"p.icon\"></ion-icon>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n\n\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app> -->\n";

/***/ })

},
/******/ __webpack_require__ => { // webpackRuntimeModules
/******/ var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
/******/ __webpack_require__.O(0, ["vendor"], () => (__webpack_exec__(14431)));
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main.js.map