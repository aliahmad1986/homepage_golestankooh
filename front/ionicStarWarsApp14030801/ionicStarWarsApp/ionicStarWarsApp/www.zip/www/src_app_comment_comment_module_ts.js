"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_comment_comment_module_ts"],{

/***/ 96946:
/*!***************************************************!*\
  !*** ./src/app/comment/comment-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommentPageRoutingModule": () => (/* binding */ CommentPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _comment_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comment.page */ 69844);




const routes = [
    {
        path: '',
        component: _comment_page__WEBPACK_IMPORTED_MODULE_0__.CommentPage
    }
];
let CommentPageRoutingModule = class CommentPageRoutingModule {
};
CommentPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CommentPageRoutingModule);



/***/ }),

/***/ 29007:
/*!*******************************************!*\
  !*** ./src/app/comment/comment.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommentPageModule": () => (/* binding */ CommentPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _comment_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comment-routing.module */ 96946);
/* harmony import */ var _comment_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comment.page */ 69844);







let CommentPageModule = class CommentPageModule {
};
CommentPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _comment_routing_module__WEBPACK_IMPORTED_MODULE_0__.CommentPageRoutingModule
        ],
        declarations: [_comment_page__WEBPACK_IMPORTED_MODULE_1__.CommentPage]
    })
], CommentPageModule);



/***/ }),

/***/ 69844:
/*!*****************************************!*\
  !*** ./src/app/comment/comment.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CommentPage": () => (/* binding */ CommentPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _comment_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comment.page.html?ngResource */ 70631);
/* harmony import */ var _comment_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comment.page.scss?ngResource */ 4501);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);




let CommentPage = class CommentPage {
    constructor() { }
    ngOnInit() {
    }
};
CommentPage.ctorParameters = () => [];
CommentPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-comment',
        template: _comment_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_comment_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CommentPage);



/***/ }),

/***/ 4501:
/*!******************************************************!*\
  !*** ./src/app/comment/comment.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "div {\n  font-family: B_Homa;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbW1lbnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ssbUJBQUE7QUFDTCIsImZpbGUiOiJjb21tZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImRpdntcclxuICAgICBmb250LWZhbWlseTogQl9Ib21hO1xyXG4gICB9Il19 */";

/***/ }),

/***/ 70631:
/*!******************************************************!*\
  !*** ./src/app/comment/comment.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n<div>\n  <h2 style=\"text-align: center;\">نظر خود را در مورد این بخش بنویسید</h2>\n</div>\n<div>\n<form style=\"\" >\n  <div style=\"\">\n    <ion-card style=\"padding: 25px; border-radius: 20px;\n    border-color: #7e8181;\n    box-shadow: 1px 1px 1px 2px #b6b7b7; max-width:800px;\">\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">نام و نام خانوادگی*</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"\"style=\"text-align: center; width: 700px;\">\n         <input type=\"text\" class=\"form-control\"  >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">آدرس ایمیل</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\" placeholder=\"09\" class=\"form-control\"  >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">نظر*</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\" style=\"height: 200px;\" placeholder=\"\" class=\"form-control\"  >\n        </div>\n     </div>\n    </div>\n  </div>\n\n  </ion-card>\n  </div>\n  </form>\n</div>\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_comment_comment_module_ts.js.map