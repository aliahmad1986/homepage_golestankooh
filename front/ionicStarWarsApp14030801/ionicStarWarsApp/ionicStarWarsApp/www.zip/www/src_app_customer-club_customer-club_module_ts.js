"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_customer-club_customer-club_module_ts"],{

/***/ 27656:
/*!***************************************************************!*\
  !*** ./src/app/customer-club/customer-club-routing.module.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerClubPageRoutingModule": () => (/* binding */ CustomerClubPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _customer_club_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-club.page */ 10262);




const routes = [
    {
        path: '',
        component: _customer_club_page__WEBPACK_IMPORTED_MODULE_0__.CustomerClubPage
    }
];
let CustomerClubPageRoutingModule = class CustomerClubPageRoutingModule {
};
CustomerClubPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CustomerClubPageRoutingModule);



/***/ }),

/***/ 31203:
/*!*******************************************************!*\
  !*** ./src/app/customer-club/customer-club.module.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerClubPageModule": () => (/* binding */ CustomerClubPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _customer_club_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-club-routing.module */ 27656);
/* harmony import */ var _customer_club_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer-club.page */ 10262);







let CustomerClubPageModule = class CustomerClubPageModule {
};
CustomerClubPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _customer_club_routing_module__WEBPACK_IMPORTED_MODULE_0__.CustomerClubPageRoutingModule
        ],
        declarations: [_customer_club_page__WEBPACK_IMPORTED_MODULE_1__.CustomerClubPage]
    })
], CustomerClubPageModule);



/***/ }),

/***/ 10262:
/*!*****************************************************!*\
  !*** ./src/app/customer-club/customer-club.page.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CustomerClubPage": () => (/* binding */ CustomerClubPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _customer_club_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./customer-club.page.html?ngResource */ 44071);
/* harmony import */ var _customer_club_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./customer-club.page.scss?ngResource */ 87927);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _users_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../users-api.service */ 57569);








let CustomerClubPage = class CustomerClubPage {
    constructor(router, navCtrl, activatedRoute, title, service) {
        this.router = router;
        this.navCtrl = navCtrl;
        this.activatedRoute = activatedRoute;
        this.title = title;
        this.service = service;
        this.name = "";
        this.family = "";
        this.marriagedate = "";
        this.phonenumber = "";
        this.email = "";
        this.birthdate = "";
        this.birthcity = "";
        this.instagramid = "";
        title.setTitle("باشگاه مشتریان");
    }
    ngOnInit() {
        this.name;
        this.family;
        this.marriagedate;
        this.phonenumber;
        this.email;
        this.birthdate;
        this.birthcity;
        this.instagramid;
    }
    exitToHome() {
        this.navCtrl.navigateForward('/home');
    }
    addUsers() {
        var users = {
            name: this.name,
            family: this.family,
            marriagedate: this.marriagedate,
            phonenumber: this.phonenumber,
            email: this.email,
            birthdate: this.birthdate,
            birthcity: this.birthcity,
            instagramid: this.instagramid
        };
        if (users.name == "" || users.family == "" || users.phonenumber == "") {
            alert("لطفا مشخصات خود را تکمیل کنید");
        }
        else {
            this.service.addUsers(users).subscribe({
                next: (res) => {
                    if (res != null) {
                        alert("ثبت نام انجام شد");
                        this.name = "";
                        this.family = "";
                        this.marriagedate = "";
                        this.phonenumber = "";
                        this.email = "";
                        this.birthdate = "";
                        this.birthcity = "";
                        this.instagramid = "";
                    }
                    else {
                        alert("خطا در عملیات ثبت نام");
                    }
                }
            });
        }
    }
};
CustomerClubPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__.ActivatedRoute },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__.Title },
    { type: _users_api_service__WEBPACK_IMPORTED_MODULE_2__.UsersApiService }
];
CustomerClubPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-customer-club',
        template: _customer_club_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_customer_club_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], CustomerClubPage);



/***/ }),

/***/ 57569:
/*!**************************************!*\
  !*** ./src/app/users-api.service.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "UsersApiService": () => (/* binding */ UsersApiService)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/common/http */ 58987);



let UsersApiService = class UsersApiService {
    constructor(http) {
        this.http = http;
        this.usersAPIUrl = "https://localhost:7225/api";
        this.baseUrl = "https://localhost:7225/api/Users";
    }
    addUsers(data) {
        return this.http.post(this.usersAPIUrl + '/Users', data);
    }
    checkUsers(data) {
        const httpOptions = { headers: ({ 'phoneNumber': 'application/json' }) };
        return this.http.post(this.baseUrl + '/authenticate', JSON.stringify(data), httpOptions);
    }
};
UsersApiService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_0__.HttpClient }
];
UsersApiService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], UsersApiService);



/***/ }),

/***/ 87927:
/*!******************************************************************!*\
  !*** ./src/app/customer-club/customer-club.page.scss?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = ".exit-btn {\n  transform: scaleX(-1);\n}\n\n.logo-style {\n  text-align: center;\n}\n\ndiv {\n  font-family: Ray;\n}\n\n@media screen and (max-width: 1200px) {\n  .home-detailes-style {\n    z-index: 1;\n    font-family: Ray;\n  }\n}\n\n.home-detailes-style {\n  font-size: 16px;\n  border-radius: 8px;\n  border-color: #002540;\n  margin-bottom: 10px;\n  display: flex;\n  list-style: none;\n  color: #002540;\n  text-align: center;\n  padding-right: 3px;\n  padding-left: 3px;\n  justify-items: center;\n  justify-content: center;\n  font-weight: bold;\n  font-family: Ray;\n}\n\n.home-detailes-style1:hover {\n  color: #002540;\n  background-color: transparent;\n  border-color: #002540;\n  z-index: 1;\n}\n\n@media screen and (max-width: 1200px) {\n  .menu-pages-card {\n    box-shadow: none;\n    background-color: transparent;\n    display: flex;\n    flex-direction: row-reverse;\n    flex-wrap: wrap-reverse;\n    position: relative;\n    justify-content: center;\n    margin-right: 16px;\n    margin-top: 16px;\n    margin-left: 16px;\n    margin-bottom: -10%;\n  }\n}\n\n.menu-pages-card {\n  box-shadow: none;\n  background-color: transparent;\n  z-index: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImN1c3RvbWVyLWNsdWIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBRU0scUJBQUE7QUFDTjs7QUFDQTtFQUNLLGtCQUFBO0FBRUw7O0FBQ0E7RUFDSyxnQkFBQTtBQUVMOztBQUFHO0VBQ0U7SUFDRSxVQUFBO0lBQ0EsZ0JBQUE7RUFHTDtBQUNGOztBQUFHO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtBQUVMOztBQUNHO0VBQ0UsY0FBQTtFQUNBLDZCQUFBO0VBQ0EscUJBQUE7RUFDQSxVQUFBO0FBRUw7O0FBQ0c7RUFDRTtJQUNFLGdCQUFBO0lBQ0EsNkJBQUE7SUFDQSxhQUFBO0lBQ0EsMkJBQUE7SUFDQSx1QkFBQTtJQUNBLGtCQUFBO0lBQ0EsdUJBQUE7SUFDQSxrQkFBQTtJQUNBLGdCQUFBO0lBQ0EsaUJBQUE7SUFDQSxtQkFBQTtFQUVMO0FBQ0Y7O0FBQUc7RUFDRSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtBQUVMIiwiZmlsZSI6ImN1c3RvbWVyLWNsdWIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmV4aXQtYnRue1xyXG4gICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZVgoLTEpO1xyXG4gICAgICB0cmFuc2Zvcm06IHNjYWxlWCgtMSk7XHJcbiAgICB9XHJcbi5sb2dvLXN0eWxle1xyXG4gICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5cclxuZGl2e1xyXG4gICAgIGZvbnQtZmFtaWx5OiBSYXk7XHJcbiAgIH1cclxuICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTIwMHB4KSB7XHJcbiAgICAgLmhvbWUtZGV0YWlsZXMtc3R5bGV7XHJcbiAgICAgICB6LWluZGV4OiAxO1xyXG4gICAgICAgZm9udC1mYW1pbHk6IFJheTsgXHJcbiAgICAgXHJcbiAgICAgfVxyXG4gICB9XHJcbiAgIC5ob21lLWRldGFpbGVzLXN0eWxle1xyXG4gICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgICAgYm9yZGVyLWNvbG9yOiAjMDAyNTQwO1xyXG4gICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICAgZGlzcGxheTpmbGV4OyAgXHJcbiAgICAgbGlzdC1zdHlsZTpub25lO1xyXG4gICAgIGNvbG9yOiMwMDI1NDA7XHJcbiAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgIHBhZGRpbmctcmlnaHQ6IDNweDtcclxuICAgICBwYWRkaW5nLWxlZnQ6IDNweDtcclxuICAgICBqdXN0aWZ5LWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgZm9udC1mYW1pbHk6IFJheTsgXHJcbiAgIFxyXG4gICB9XHJcbiAgIC5ob21lLWRldGFpbGVzLXN0eWxlMTpob3ZlcntcclxuICAgICBjb2xvcjogIzAwMjU0MDtcclxuICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICBib3JkZXItY29sb3I6ICMwMDI1NDA7XHJcbiAgICAgei1pbmRleDogMTtcclxuICAgXHJcbiAgIH1cclxuICAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTIwMHB4KSB7XHJcbiAgICAgLm1lbnUtcGFnZXMtY2FyZHtcclxuICAgICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93LXJldmVyc2U7XHJcbiAgICAgICBmbGV4LXdyYXA6IHdyYXAtcmV2ZXJzZTtcclxuICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xyXG4gICAgICAgbWFyZ2luLXRvcDogMTZweDtcclxuICAgICAgIG1hcmdpbi1sZWZ0OiAxNnB4O1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTogLTEwJTtcclxuICAgICAgIH1cclxuICAgfVxyXG4gICAubWVudS1wYWdlcy1jYXJke1xyXG4gICAgIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICAgei1pbmRleDogMTtcclxuICAgXHJcbiAgICAgfSJdfQ== */";

/***/ }),

/***/ 44071:
/*!******************************************************************!*\
  !*** ./src/app/customer-club/customer-club.page.html?ngResource ***!
  \******************************************************************/
/***/ ((module) => {

module.exports = "<ion-content>\n  <ion-content color=\"blue\">\n    <ion-button color=\"danger\" (click)=\"exitToHome()\" style=\"margin: 20px;\" title=\"بازگشت به صفحه ی نخست\">\n      <ion-icon class=\"exit-btn\" name=\"exit\"></ion-icon>\n    </ion-button>\n<div class=\"logo-style\">\n    <img  src=\"assets\\imges\\logo1.png\" style=\"width: 100px; margin-top: -45px;\">\n  </div>\n\n\n  <div  style=\"text-align: center;\">\n    <div class=\"menu-pages text-center\" style=\"display: flex; justify-content: center;\" >\n    <ion-card class=\"menu-pages-card scroll\">\n    <li class=\"nav-item m-2\">\n   \n        <button class=\"mt-1 btn home-detailes-style home-detailes-style1\" style=\"width: 98px;\" onclick=\"window.open('https://web.golestankooh.com/sign-up/');\">مشاهده</button>\n    </li>\n    </ion-card>\n    </div>\n    </div>\n\n  <!--\n  <div>\n    <h1 style=\"text-align: center; color: #002540;\">ثـــبت نـــام در باشگاه مشتریان</h1>\n  </div>\n  \n   <div style=\"text-align: center;\">\n    <ion-card>\n    <div style=\"margin-top: 50px;\">\n      <ion-label>\n        <input style=\"border-radius: 7%;\">\n      </ion-label>نام و نام خانوادگی\n    </div>\n    <div></div>\n    <div></div>\n    <div></div>\n  \n  </ion-card>\n  </div> \n   \n  <form style=\"\" >\n  <div style=\"display: flex; justify-content: center;\">\n    <ion-card style=\"padding: 25px; border-radius: 20px;\n    border-color: #7e8181;\n    box-shadow: 1px 1px 1px 2px #b6b7b7; max-width:800px;\">\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">نام *</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"\"style=\"text-align: center; width: 700px;\">\n         <input type=\"text\" class=\"form-control\" name=\"name\" [(ngModel)]=\"name\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">نام خانوادگی*</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\"  class=\"form-control\" name=\"family\" [(ngModel)]=\"family\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">شماره موبایل*</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\" placeholder=\"09\" class=\"form-control\" name=\"phonenumber\" [(ngModel)]=\"phonenumber\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">ایمیل</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\" placeholder=\"اختیاری\" class=\"form-control\" name=\"email\" [(ngModel)]=\"email\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">آیدی اینستاگرام</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\" placeholder=\"اختیاری\" class=\"form-control\" name=\"instagramid\" [(ngModel)]=\"instagramid\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">تاریخ تولد</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"date\" placeholder=\"اختیاری\" class=\"form-control\" name=\"birthdate\" [(ngModel)]=\"birthdate\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">تاریخ ازدواج</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"date\" placeholder=\"اختیاری\" class=\"form-control\" name=\"marriagedate\" [(ngModel)]=\"marriagedate\" >\n        </div>\n     </div>\n    </div>\n  </div>\n  <div class=\"form-group\" dir=\"rtl\" >\n    <div >\n     <label class=\"my-2\" style=\"color: #002540;\">شهر محل سکونت</label>\n      <div class=\"row\"style=\"text-align: center;\">\n        <div class=\"col-5\"style=\"text-align: center;width: 700px;\">\n         <input type=\"text\" placeholder=\"اختیاری\" class=\"form-control\" name=\"birthcity\" [(ngModel)]=\"birthcity\" >\n        </div>\n     </div>\n    </div>\n  </div>\n\n  </ion-card>\n  </div>\n  </form>\n  \n  \n  \n  <div style=\"text-align: center;\">\n    <ion-button color=\"danger\"style=\"margin-right: 20px;\" (click)=\"exitToHome()\">\n      <ion-icon name=\"close-outline\" ></ion-icon>\n          لغو</ion-button>\n    <ion-button (click)=\"addUsers()\" color=\"success\">\n      <ion-icon name=\"checkmark-outline\"></ion-icon>\n      ثبت</ion-button>\n  \n  </div>\n-->\n  </ion-content>\n  \n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_customer-club_customer-club_module_ts.js.map