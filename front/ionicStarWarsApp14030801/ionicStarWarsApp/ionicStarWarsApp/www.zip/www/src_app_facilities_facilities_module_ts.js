"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_facilities_facilities_module_ts"],{

/***/ 46891:
/*!*********************************************************!*\
  !*** ./src/app/facilities/facilities-routing.module.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FacilitiesPageRoutingModule": () => (/* binding */ FacilitiesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _facilities_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./facilities.page */ 51934);




const routes = [
    {
        path: '',
        component: _facilities_page__WEBPACK_IMPORTED_MODULE_0__.FacilitiesPage
    }
];
let FacilitiesPageRoutingModule = class FacilitiesPageRoutingModule {
};
FacilitiesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], FacilitiesPageRoutingModule);



/***/ }),

/***/ 16682:
/*!*************************************************!*\
  !*** ./src/app/facilities/facilities.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FacilitiesPageModule": () => (/* binding */ FacilitiesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _facilities_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./facilities-routing.module */ 46891);
/* harmony import */ var _facilities_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./facilities.page */ 51934);
/* harmony import */ var _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../toolbar/toolbar.module */ 63095);
/* harmony import */ var _mainfooter_mainfooter_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../mainfooter/mainfooter.module */ 20890);









let FacilitiesPageModule = class FacilitiesPageModule {
};
FacilitiesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_6__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_7__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule,
            _facilities_routing_module__WEBPACK_IMPORTED_MODULE_0__.FacilitiesPageRoutingModule,
            _toolbar_toolbar_module__WEBPACK_IMPORTED_MODULE_2__.ToolbarModule,
            _mainfooter_mainfooter_module__WEBPACK_IMPORTED_MODULE_3__.MainfooterCModule
        ],
        declarations: [_facilities_page__WEBPACK_IMPORTED_MODULE_1__.FacilitiesPage]
    })
], FacilitiesPageModule);



/***/ }),

/***/ 51934:
/*!***********************************************!*\
  !*** ./src/app/facilities/facilities.page.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "FacilitiesPage": () => (/* binding */ FacilitiesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _facilities_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./facilities.page.html?ngResource */ 60626);
/* harmony import */ var _facilities_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./facilities.page.scss?ngResource */ 30400);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ 34497);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ 93819);







let FacilitiesPage = class FacilitiesPage {
    constructor(title, navCtrl) {
        this.title = title;
        this.navCtrl = navCtrl;
        title.setTitle("امکانات مجموعه");
    }
    ngOnDestroy() {
        // Stop autoplay when navigating to a new page
        this.myVideo.nativeElement.autoplay = false;
    }
    ngOnInit() {
    }
    goToHome() {
        this.navCtrl.navigateForward('/home');
    }
    waters() {
        this.navCtrl.navigateForward('/waters');
    }
    hotels() {
        this.navCtrl.navigateForward('/hotels');
    }
    gotosuites() {
        this.navCtrl.navigateForward('/suites');
    }
    burritoRestaurant() {
        this.navCtrl.navigateForward('/burrito-restaurant');
    }
    sportGrounds() {
        this.navCtrl.navigateForward('/sport-grounds');
    }
    traditionalRestaurant() {
        this.navCtrl.navigateForward('/traditional-restaurant');
    }
    deli() {
        this.navCtrl.navigateForward('/deli');
    }
    hall() {
        this.navCtrl.navigateForward('/hall');
    }
    pantry() {
        this.navCtrl.navigateForward('/pantry');
    }
    coffe() {
        this.navCtrl.navigateForward('/coffe');
    }
    bazaar() {
        this.navCtrl.navigateForward('/bazaar');
    }
    greenhouses() {
        this.navCtrl.navigateForward('/greenhouses');
    }
    gameCenter() {
        this.navCtrl.navigateForward('/gamecenter');
    }
    royalsuits() {
        this.navCtrl.navigateForward('/royalsuits');
    }
};
FacilitiesPage.ctorParameters = () => [
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__.Title },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.NavController }
];
FacilitiesPage.propDecorators = {
    myVideo: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_4__.ViewChild, args: ['myVideo',] }]
};
FacilitiesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-facilities',
        template: _facilities_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_facilities_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], FacilitiesPage);



/***/ }),

/***/ 30400:
/*!************************************************************!*\
  !*** ./src/app/facilities/facilities.page.scss?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = ".main1 {\n  background-image: url(\"https://golestankooh.com/apppictures/mainback.png\");\n  background-size: cover;\n}\n\n.card-slider {\n  max-height: 275px;\n  border-radius: 20px;\n  margin-top: 10.5%;\n  margin-left: 9%;\n  margin-right: 9%;\n  margin-bottom: 10px;\n}\n\n@media screen and (max-width: 700px) {\n  .card-slider {\n    border-radius: 20px;\n    margin-top: 17%;\n    margin-bottom: 10px;\n  }\n}\n\n.brightness-img img {\n  transition: transform 0.5s, filter 1.5s ease-in-out;\n  transform-origin: center center;\n  filter: brightness(80%);\n}\n\n/* The Transformation */\n\n.brightness-img:hover img {\n  filter: brightness(100%);\n  transform: scale(1.1);\n}\n\n.golestan {\n  width: 300px;\n  height: 45px;\n  margin-bottom: 48px;\n  font-family: Georgia, \"Times New Roman\", Times, serif;\n}\n\n@media screen and (max-width: 1200px) {\n  .golestan {\n    display: flex;\n    justify-content: center;\n    color: #002540;\n    margin-bottom: 40px;\n  }\n}\n\n.namebrand {\n  display: flex;\n  justify-content: center;\n}\n\n@media screen and (max-width: 1200px) {\n  .namebrand {\n    margin-top: 0px;\n  }\n}\n\nlink-style:link {\n  text-decoration: none;\n}\n\nlink-style:hover {\n  text-decoration: none;\n}\n\n.logo-text-style {\n  width: 150px;\n}\n\n.Menu-Black-Style {\n  size: 1.5%;\n}\n\n.login-Black-Style {\n  size: 1.5%;\n}\n\n@media screen and (max-width: 700px) {\n  .menu-pages {\n    background-color: transparent;\n  }\n}\n\n@media screen and (max-width: 700px) {\n  .menu-pages-card {\n    box-shadow: none;\n    background-color: transparent;\n    display: flex;\n    flex-direction: row-reverse;\n    flex-wrap: wrap;\n    position: relative;\n    justify-content: center;\n    margin-right: 16px;\n    margin-top: 16px;\n    margin-left: 16px;\n  }\n}\n\n@media screen and (max-width: 700px) {\n  .home-detailes-style {\n    visibility: hidden;\n    margin-top: -155px;\n  }\n}\n\n@media screen and (min-width: 700px) {\n  .home-detailes-style-mobile {\n    visibility: hidden;\n    margin-bottom: -174px;\n  }\n}\n\n@media screen and (max-width: 700px) {\n  .home-detailes-style-mobile {\n    font-size: 16px;\n    display: flex;\n    list-style: none;\n    color: white;\n    text-align: center;\n    padding-right: 3px;\n    padding-left: 3px;\n    font-weight: bold;\n    justify-content: center;\n    border-radius: 8px;\n  }\n}\n\n.menu-pages {\n  margin-top: -50px;\n  background-color: transparent;\n}\n\n.menu-pages-card {\n  box-shadow: none;\n  background-color: transparent;\n}\n\n.logo-text {\n  text-align: end !important;\n  justify-content: end !important;\n  justify-items: end !important;\n}\n\n.home-detailes-style {\n  font-size: 16px;\n  border-radius: 8px;\n  margin-bottom: 10px;\n  display: flex;\n  list-style: none;\n  color: white;\n  text-align: center;\n  padding-right: 3px;\n  padding-left: 3px;\n  justify-items: center;\n  justify-content: center;\n  font-weight: bold;\n}\n\n.home-detailes-style1:hover {\n  color: #002540;\n  background-color: transparent;\n  border-color: #002540;\n}\n\n.home-detailes-style1 {\n  color: #002540;\n  background-color: transparent;\n  text-align: center;\n}\n\n.bashgah {\n  margin-right: 3px;\n}\n\n.Main-Pahe-Bottom {\n  width: 85%;\n  object-fit: cover;\n  object-position: center;\n  margin-top: 30px;\n  border-radius: 20px;\n  max-width: 750px;\n  max-height: 270px;\n}\n\n.contactus-style1 {\n  vertical-align: text-bottom;\n  margin-top: 15px;\n  margin-left: 6px;\n  font-size: smaller;\n  size: 15px;\n  border-radius: 15px;\n  width: 153px;\n  height: 25px;\n  color: white;\n  background-color: #002540;\n}\n\n.contactus-style2 {\n  font-size: 13px;\n}\n\ndiv {\n  font-family: Ray;\n}\n\n.contactus-style {\n  vertical-align: text-bottom;\n  margin-top: 15px;\n  margin-left: 6px;\n  size: 15px;\n  border-radius: 15px;\n  width: 153px;\n  height: 20px;\n  color: white;\n  background-color: #002540;\n}\n\n.logotext-style2 {\n  text-align: right;\n  justify-content: end !important;\n  justify-items: end !important;\n}\n\n:root[mode=ios] .muli,\n:root[mode=md] .muli {\n  font-family: \"Ray\" !important;\n}\n\n.link-insta {\n  -webkit-text-decoration-color: whitesmoke;\n          text-decoration-color: whitesmoke;\n}\n\n.link-insta:link {\n  color: whitesmoke;\n}\n\n@media screen and (min-width: 1200px) {\n  .videomain {\n    margin-left: 20%;\n    margin-right: 20%;\n    margin-top: 10%;\n  }\n}\n\n.video-container {\n  position: relative;\n  padding-bottom: 56.25%;\n  padding-top: 0px;\n  height: 0;\n  overflow: hidden;\n}\n\n.video-container iframe,\n.video-container object,\n.video-container embed {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n\nvideo {\n  max-width: 100%;\n  height: auto;\n}\n\n@media screen and (max-width: 1200px) {\n  video {\n    max-width: 90%;\n    height: auto;\n    margin-top: 20%;\n    margin-left: 5%;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZhY2lsaXRpZXMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0UsMEVBQUE7RUFDQSxzQkFBQTtBQUNGOztBQUVBO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFDRjs7QUFDQTtFQUNFO0lBQ0UsbUJBQUE7SUFDQSxlQUFBO0lBQ0EsbUJBQUE7RUFFRjtBQUNGOztBQUVBO0VBQ0UsbURBQUE7RUFDQSwrQkFBQTtFQUNBLHVCQUFBO0FBQUY7O0FBR0EsdUJBQUE7O0FBQ0E7RUFDRSx3QkFBQTtFQUNBLHFCQUFBO0FBQUY7O0FBR0E7RUFFRSxZQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EscURBQUE7QUFERjs7QUFHQTtFQUNFO0lBQ0UsYUFBQTtJQUNBLHVCQUFBO0lBQ0EsY0FBQTtJQUNBLG1CQUFBO0VBQUY7QUFDRjs7QUFFQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtBQUFGOztBQUdBO0VBQ0U7SUFDRSxlQUFBO0VBQUY7QUFDRjs7QUFPQTtFQUNFLHFCQUFBO0FBTEY7O0FBT0E7RUFDRSxxQkFBQTtBQUpGOztBQU1BO0VBQ0UsWUFBQTtBQUhGOztBQUtBO0VBQ0UsVUFBQTtBQUZGOztBQUlBO0VBQ0UsVUFBQTtBQURGOztBQUlBO0VBQ0U7SUFDRSw2QkFBQTtFQURGO0FBQ0Y7O0FBS0E7RUFDRTtJQUNFLGdCQUFBO0lBQ0EsNkJBQUE7SUFDQSxhQUFBO0lBQ0EsMkJBQUE7SUFDQSxlQUFBO0lBQ0Esa0JBQUE7SUFDQSx1QkFBQTtJQUNBLGtCQUFBO0lBQ0EsZ0JBQUE7SUFDQSxpQkFBQTtFQUhGO0FBQ0Y7O0FBTUE7RUFDRTtJQUNFLGtCQUFBO0lBQ0Esa0JBQUE7RUFKRjtBQUNGOztBQVFBO0VBQ0U7SUFDRSxrQkFBQTtJQUNBLHFCQUFBO0VBTkY7QUFDRjs7QUFVQTtFQUNFO0lBQ0EsZUFBQTtJQUNBLGFBQUE7SUFDQSxnQkFBQTtJQUNBLFlBQUE7SUFDQSxrQkFBQTtJQUNBLGtCQUFBO0lBQ0EsaUJBQUE7SUFDQSxpQkFBQTtJQUNBLHVCQUFBO0lBQ0Esa0JBQUE7RUFSQTtBQUNGOztBQVdBO0VBQ0UsaUJBQUE7RUFDQSw2QkFBQTtBQVRGOztBQWFBO0VBQ0UsZ0JBQUE7RUFDQSw2QkFBQTtBQVZGOztBQWNBO0VBQ0UsMEJBQUE7RUFDQSwrQkFBQTtFQUNBLDZCQUFBO0FBWEY7O0FBY0E7RUFDRSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLHVCQUFBO0VBQ0EsaUJBQUE7QUFYRjs7QUFlQTtFQUNFLGNBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0FBWkY7O0FBZUU7RUFFRSxjQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtBQWJKOztBQWVJO0VBQ0UsaUJBQUE7QUFaTjs7QUFlSTtFQUNFLFVBQUE7RUFDQSxpQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFaTjs7QUFlTTtFQUNFLDJCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFaUjs7QUFnQk07RUFDRSxlQUFBO0FBYlI7O0FBZ0JNO0VBQ0UsZ0JBQUE7QUFiUjs7QUFpQlE7RUFDRSwyQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtBQWRWOztBQWtCVTtFQUNFLGlCQUFBO0VBQ0EsK0JBQUE7RUFDQSw2QkFBQTtBQWZaOztBQW1CWTs7RUFHViw2QkFBQTtBQWpCRjs7QUFxQkE7RUFDRSx5Q0FBQTtVQUFBLGlDQUFBO0FBbEJGOztBQW9CQTtFQUNFLGlCQUFBO0FBakJGOztBQW9CQTtFQUNFO0lBQ0EsZ0JBQUE7SUFDQSxpQkFBQTtJQUNBLGVBQUE7RUFqQkE7QUFDRjs7QUFzQkE7RUFDRSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7QUFwQkY7O0FBdUJBOzs7RUFHRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFwQkY7O0FBc0JBO0VBQ0UsZUFBQTtFQUNBLFlBQUE7QUFuQkY7O0FBcUJBO0VBQ0E7SUFDRSxjQUFBO0lBQ0EsWUFBQTtJQUNBLGVBQUE7SUFDQSxlQUFBO0VBbEJBO0FBQ0YiLCJmaWxlIjoiZmFjaWxpdGllcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWFpbjF7XHJcbiAgYmFja2dyb3VuZC1pbWFnZTp1cmwoJ2h0dHBzOi8vZ29sZXN0YW5rb29oLmNvbS9hcHBwaWN0dXJlcy9tYWluYmFjay5wbmcnKTtcclxuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG5cclxufVxyXG4uY2FyZC1zbGlkZXJ7XHJcbiAgbWF4LWhlaWdodDogMjc1cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICBtYXJnaW4tdG9wOiAxMC41JTtcclxuICBtYXJnaW4tbGVmdDogOSU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA5JTtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcwMHB4KSB7XHJcbiAgLmNhcmQtc2xpZGVye1xyXG4gICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgIG1hcmdpbi10b3A6IDE3JTtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgfVxyXG59XHJcblxyXG5cclxuLmJyaWdodG5lc3MtaW1nIGltZyB7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuNXMsIGZpbHRlciAxLjVzIGVhc2UtaW4tb3V0O1xyXG4gIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlciBjZW50ZXI7XHJcbiAgZmlsdGVyOiBicmlnaHRuZXNzKDgwJSk7XHJcbn1cclxuIFxyXG4vKiBUaGUgVHJhbnNmb3JtYXRpb24gKi9cclxuLmJyaWdodG5lc3MtaW1nOmhvdmVyIGltZyB7XHJcbiAgZmlsdGVyOiBicmlnaHRuZXNzKDEwMCUpO1xyXG4gIHRyYW5zZm9ybTogc2NhbGUoMS4xKTtcclxufVxyXG5cclxuLmdvbGVzdGFue1xyXG5cclxuICB3aWR0aDogMzAwcHg7XHJcbiAgaGVpZ2h0OiA0NXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDQ4cHg7XHJcbiAgZm9udC1mYW1pbHk6R2VvcmdpYSwgJ1RpbWVzIE5ldyBSb21hbicsIFRpbWVzLCBzZXJpZjtcclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMjAwcHgpIHtcclxuICAuZ29sZXN0YW57XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBjb2xvcjogIzAwMjU0MDtcclxuICAgIG1hcmdpbi1ib3R0b206IDQwcHg7XHJcbiAgfVxyXG59XHJcbi5uYW1lYnJhbmQge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gIC5uYW1lYnJhbmQge1xyXG4gICAgbWFyZ2luLXRvcDogMHB4O1xyXG5cclxuICB9XHJcbn1cclxuXHJcbi5saW5rLXN0eWxle1xyXG5cclxufVxyXG5saW5rLXN0eWxlOmxpbmsge1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG5saW5rLXN0eWxlOmhvdmVyIHtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuLmxvZ28tdGV4dC1zdHlsZXtcclxuICB3aWR0aDogMTUwcHg7XHJcbn1cclxuLk1lbnUtQmxhY2stU3R5bGV7XHJcbiAgc2l6ZTogMS41JTtcclxufVxyXG4ubG9naW4tQmxhY2stU3R5bGV7XHJcbiAgc2l6ZTogMS41JTsgXHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcwMHB4KSB7XHJcbiAgLm1lbnUtcGFnZXN7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxuXHJcblxyXG4gIH1cclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiA3MDBweCkge1xyXG4gIC5tZW51LXBhZ2VzLWNhcmR7XHJcbiAgICBib3gtc2hhZG93OiBub25lO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IHJvdy1yZXZlcnNlO1xyXG4gICAgZmxleC13cmFwOiB3cmFwO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE2cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxNnB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE2cHg7XHJcblxyXG4gICAgfVxyXG59XHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDcwMHB4KSB7XHJcbiAgLmhvbWUtZGV0YWlsZXMtc3R5bGV7XHJcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICBtYXJnaW4tdG9wOiAtMTU1cHg7XHJcbiAgICBcclxuICBcclxuICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNzAwcHgpIHtcclxuICAuaG9tZS1kZXRhaWxlcy1zdHlsZS1tb2JpbGUge1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogLTE3NHB4O1xyXG5cclxuICBcclxuICB9XHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNzAwcHgpIHtcclxuICAuaG9tZS1kZXRhaWxlcy1zdHlsZS1tb2JpbGUge1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBkaXNwbGF5OmZsZXg7XHJcbiAgbGlzdC1zdHlsZTpub25lO1xyXG4gIGNvbG9yOndoaXRlO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjsgXHJcbiAgcGFkZGluZy1yaWdodDogM3B4O1xyXG4gIHBhZGRpbmctbGVmdDogM3B4O1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDhweDtcclxuICB9XHJcbn1cclxuXHJcbi5tZW51LXBhZ2Vze1xyXG4gIG1hcmdpbi10b3A6IC01MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIFxyXG5cclxufVxyXG4ubWVudS1wYWdlcy1jYXJke1xyXG4gIGJveC1zaGFkb3c6IG5vbmU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7ICBcclxuICB9XHJcbiAgXHJcblxyXG4ubG9nby10ZXh0e1xyXG4gIHRleHQtYWxpZ246IGVuZCFpbXBvcnRhbnQ7XHJcbiAganVzdGlmeS1jb250ZW50OiBlbmQhaW1wb3J0YW50O1xyXG4gIGp1c3RpZnktaXRlbXM6IGVuZCFpbXBvcnRhbnQ7XHJcblxyXG59XHJcbi5ob21lLWRldGFpbGVzLXN0eWxle1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBkaXNwbGF5OmZsZXg7ICBcclxuICBsaXN0LXN0eWxlOm5vbmU7XHJcbiAgY29sb3I6d2hpdGU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIHBhZGRpbmctcmlnaHQ6IDNweDtcclxuICBwYWRkaW5nLWxlZnQ6IDNweDtcclxuICBqdXN0aWZ5LWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcblxyXG59XHJcblxyXG4uaG9tZS1kZXRhaWxlcy1zdHlsZTE6aG92ZXJ7XHJcbiAgY29sb3I6ICMwMDI1NDA7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgYm9yZGVyLWNvbG9yOiAjMDAyNTQwO1xyXG59XHJcblxyXG4gIC5ob21lLWRldGFpbGVzLXN0eWxlMVxyXG4gIHtcclxuICAgIGNvbG9yOiAjMDAyNTQwO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQ7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgfVxyXG4gICAgLmJhc2hnYWh7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogM3B4O1xyXG4gICAgfVxyXG5cclxuICAgIC5NYWluLVBhaGUtQm90dG9te1xyXG4gICAgICB3aWR0aDogODUlO1xyXG4gICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgb2JqZWN0LXBvc2l0aW9uOiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICAgIG1heC13aWR0aDogNzUwcHg7XHJcbiAgICAgIG1heC1oZWlnaHQ6IDI3MHB4O1xyXG4gICAgfVxyXG5cclxuICAgICAgLmNvbnRhY3R1cy1zdHlsZTF7XHJcbiAgICAgICAgdmVydGljYWwtYWxpZ246dGV4dC1ib3R0b20gO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDZweDtcclxuICAgICAgICBmb250LXNpemU6IHNtYWxsZXI7XHJcbiAgICAgICAgc2l6ZTogMTVweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgICAgIHdpZHRoOiAxNTNweDtcclxuICAgICAgICBoZWlnaHQ6IDI1cHg7XHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMwMDI1NDA7XHJcbiAgICAgIH1cclxuICAgICAgXHJcblxyXG4gICAgICAuY29udGFjdHVzLXN0eWxlMntcclxuICAgICAgICBmb250LXNpemU6MTNweDtcclxuICAgICAgfVxyXG5cclxuICAgICAgZGl2e1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBSYXk7XHJcbiAgICAgIH1cclxuXHJcblxyXG4gICAgICAgIC5jb250YWN0dXMtc3R5bGV7XHJcbiAgICAgICAgICB2ZXJ0aWNhbC1hbGlnbjp0ZXh0LWJvdHRvbSA7XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgICAgICAgbWFyZ2luLWxlZnQ6IDZweDtcclxuICAgICAgICAgIHNpemU6IDE1cHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxNXB4O1xyXG4gICAgICAgICAgd2lkdGg6IDE1M3B4O1xyXG4gICAgICAgICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogIzAwMjU0MDtcclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICAgIC5sb2dvdGV4dC1zdHlsZTJ7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGVuZCFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIGp1c3RpZnktaXRlbXM6IGVuZCFpbXBvcnRhbnQ7fVxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICA6cm9vdFttb2RlPWlvc10gLm11bGksXHJcbjpyb290W21vZGU9bWRdIC5tdWxpe1xyXG4gIC8vIC0taW9uLWZvbnQtZmFtaWx5OiAgJ0IgSG9tYSchaW1wb3J0YW50O1xyXG4gIGZvbnQtZmFtaWx5OiAgJ1JheScgIWltcG9ydGFudDtcclxufVxyXG4gICAgICAgXHJcblxyXG4ubGluay1pbnN0YXtcclxuICB0ZXh0LWRlY29yYXRpb24tY29sb3I6IHdoaXRlc21va2U7XHJcbn1cclxuLmxpbmstaW5zdGE6bGlua3tcclxuICBjb2xvcjogd2hpdGVzbW9rZTtcclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTIwMHB4KSB7XHJcbiAgLnZpZGVvbWFpbntcclxuICBtYXJnaW4tbGVmdDogMjAlO1xyXG4gIG1hcmdpbi1yaWdodDogMjAlO1xyXG4gIG1hcmdpbi10b3A6IDEwJTtcclxufVxyXG5cclxuXHJcbn1cclxuXHJcbi52aWRlby1jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBwYWRkaW5nLWJvdHRvbTogNTYuMjUlO1xyXG4gIHBhZGRpbmctdG9wOiAwcHg7XHJcbiAgaGVpZ2h0OiAwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbn1cclxuXHJcbi52aWRlby1jb250YWluZXIgaWZyYW1lLFxyXG4udmlkZW8tY29udGFpbmVyIG9iamVjdCxcclxuLnZpZGVvLWNvbnRhaW5lciBlbWJlZCB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxufVxyXG52aWRlbyB7XHJcbiAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogYXV0bztcclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMjAwcHgpIHtcclxudmlkZW97XHJcbiAgbWF4LXdpZHRoOiA5MCU7XHJcbiAgaGVpZ2h0OiBhdXRvO1xyXG4gIG1hcmdpbi10b3A6IDIwJTtcclxuICBtYXJnaW4tbGVmdDogNSU7XHJcblxyXG59XHJcblxyXG5cclxufVxyXG4iXX0= */";

/***/ }),

/***/ 60626:
/*!************************************************************!*\
  !*** ./src/app/facilities/facilities.page.html?ngResource ***!
  \************************************************************/
/***/ ((module) => {

module.exports = "<ion-content  overflow-scroll=\"false\" >\n  <app-toolbar></app-toolbar>\n  <div class=\"main1\">\n    <div>\n      <div class=\"videomain\">\n        <video #myVideo controls autoplay style=\"border-radius: 45px;\">\n          <source src=\"https://golestankooh.com/videos/mainvideo.mp4\" type=\"video/mp4\">\n          Your browser does not support the video tag.\n        </video>\n      </div>\n\n      <div class=\"namebrand\">\n        <img class=\"golestan\" src=\"https://golestankooh.com/apppictures/logotype.png\">\n       </div>\n\n  \n\n\n          <div class=\"menu-pages text-center\"  >\n            <div class=\"menu-pages text-center\" style=\"display: flex; justify-content: center;\" >\n            <ion-card class=\"menu-pages-card scroll\"  style=\"margin: 16px;\">\n    \n      <div class=\"home-detailes-style \" dir=\"rtl\">\n    \n        <li class=\"nav-item m-2\" style=\"margin-left: 6px;\">\n            <img (click)=\"waters()\" src=\"https://golestankooh.com/apppictures/facilities/1.png\" style=\"width: 60px; cursor: pointer;\">\n            <button class=\" mt-1 btn home-detailes-style home-detailes-style1 me-1\" (click)=\"waters()\"\n             style=\"width: 115px;\"> مجـــموعه آبـــی </button>\n        </li>\n    \n        <li class=\"nav-item m-2\">\n            <img (click)=\"hotels()\"  src=\"https://golestankooh.com/apppictures/facilities/2.png\" style=\"width: 60px; cursor: pointer;\">\n            <button class=\" mt-1 btn home-detailes-style home-detailes-style1\" (click)=\"hotels()\"\n            style=\"width: 98px;\" >عمارت چلچراغ</button>\n        </li>\n    \n        <li class=\"nav-item m-2\">\n            <img  (click)=\"gotosuites()\" src=\"https://golestankooh.com/apppictures/facilities/3.png\" style=\"width: 60px; cursor: pointer;\">\n            <button class=\" mt-1 btn home-detailes-style home-detailes-style1\"\n             style=\"width: 120px;\" (click)=\"gotosuites()\" >  مهمانکده دهکده </button>\n        </li>\n    \n    \n        <li class=\"nav-item m-2\">\n            <img  (click)=\"burritoRestaurant()\" src=\"https://golestankooh.com/apppictures/facilities/4.png\" style=\"width: 60px; cursor: pointer;\">\n            \n            <button class=\" mt-1 btn home-detailes-style home-detailes-style1 me-1 bashgah\"\n             style=\"width: 98px; margin-left: 2px;\"  (click)=\"burritoRestaurant()\"> رستوران بوریتو</button>\n            \n        </li>\n        <li class=\"nav-item m-2\">\n            <img  (click)=\"sportGrounds()\" src=\"https://golestankooh.com/apppictures/facilities/5.png\" style=\"width: 60px; cursor: pointer;\">\n            \n            <button class=\"  mt-1 btn home-detailes-style home-detailes-style1 \" \n            style=\"width: 110px;\" (click)=\"sportGrounds()\">زمین های ورزشی </button>\n            \n        </li>\n        <li class=\"nav-item text-center m-2\">\n            <img  (click)=\"traditionalRestaurant()\" src=\"https://golestankooh.com/apppictures/facilities/6.png\" style=\"width: 60px; cursor: pointer;\">\n            \n            <button class=\" mt-1 btn home-detailes-style home-detailes-style1 \"\n             style=\"width: 98px; margin-left: 5px;\" (click)=\"traditionalRestaurant()\"> باغ رستوران نابره \n    \n            </button>\n        </li>\n    \n      <li class=\"nav-item m-2\">\n          <img (click)=\"hall()\" src=\"https://golestankooh.com/apppictures/facilities/7.png\" style=\"width: 60px; cursor: pointer;\">\n          \n          <button class=\" mt-1 btn home-detailes-style home-detailes-style1 me-1 bashgah\"\n           style=\"width: 98px; margin-left: 2px;\" (click)=\"hall()\"> تـــــــــالار</button>\n          \n      </li>\n      <li class=\"nav-item m-2\">\n          <img (click)=\"pantry()\" src=\"https://golestankooh.com/apppictures/facilities/8.png\" style=\"width: 60px; cursor: pointer;\">\n          \n          <button class=\"  mt-1 btn home-detailes-style home-detailes-style1 \" \n          style=\"width: 98px;\"   (click)=\"pantry()\">شــربـت خــانـه </button>\n          \n      </li>\n      <li class=\"nav-item text-center m-2\">\n          <img (click)=\"coffe()\" src=\"https://golestankooh.com/apppictures/facilities/9.png\" style=\"width: 60px; cursor: pointer;\">\n          \n          <button class=\" mt-1 btn home-detailes-style home-detailes-style1 \"\n           style=\"width: 115px; margin-left: 5px;\" (click)=\"coffe()\"> کــــافی شـــاپ\n  \n          </button>\n      </li>\n\n    <li class=\"nav-item m-2\">\n        <img (click)=\"deli()\" src=\"https://golestankooh.com/apppictures/facilities/13.png\" style=\"width: 60px; cursor: pointer;\">\n        \n        <button class=\" mt-1 btn home-detailes-style home-detailes-style1 me-1 bashgah\" \n        style=\"width: 115px; margin-left: 2px;\" (click)=\"deli()\">گلستانفود</button>\n        \n    </li>\n    </div>\n\n    <div class=\"home-detailes-style \" dir=\"rtl\">\n\n    <li class=\"nav-item m-2\">\n        <img   (click)=\"bazaar()\" src=\"https://golestankooh.com/apppictures/facilities/11.png\" style=\"width: 60px; cursor: pointer;\">\n        \n        <button class=\"  mt-1 btn home-detailes-style home-detailes-style1 \"\n         style=\"width: 98px;\" (click)=\"bazaar()\">بـــــازارچـــــه  </button>\n        \n    </li>\n\n\n    <li class=\"nav-item text-center m-2\">\n        <img  (click)=\"greenhouses()\" src=\"https://golestankooh.com/apppictures/facilities/12.png\" style=\"width: 60px; cursor: pointer;\">\n        \n        <button class=\" mt-1 btn home-detailes-style home-detailes-style1 \"\n         style=\"width: 98px; margin-left: 5px;\"  (click)=\"greenhouses()\"> گــــلخـــــانــه\n\n        </button>\n    </li>\n\n\n  <li class=\"nav-item text-center m-2\">\n      <img  (click)=\"gameCenter()\" src=\"https://golestankooh.com/apppictures/facilities/10.png\" style=\"width: 60px; cursor: pointer;\">\n      \n      <button class=\" mt-1 btn home-detailes-style home-detailes-style1 \"\n       style=\"width: 115px; margin-left: 5px;\"  (click)=\"gameCenter()\"> گیم سنتر\n\n      </button>\n  </li>\n  <li class=\"nav-item text-center m-2\">\n    <img  (click)=\"royalsuits()\" src=\"https://golestankooh.com/apppictures/facilities/3.png\" style=\"width: 60px; cursor: pointer;\">\n    \n    <button class=\" mt-1 btn home-detailes-style home-detailes-style1 \"\n     style=\"width: 115px; margin-left: 5px;\"  (click)=\"royalsuits()\"> سوییت های vip\n\n    </button>\n</li>\n</div>\n\n\n<!--این قسمت مخصوص نسخه موبایل میباشد-->\n<div class=\"home-detailes-style-mobile \" dir=\"rtl\">\n  <li class=\"nav-item m-2\" style=\"margin-left: 6px;\">\n    <img (click)=\"waters()\" src=\"https://golestankooh.com/apppictures/facilities/1.png\" style=\"width: 60px; cursor: pointer;\">\n    <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 me-1\" (click)=\"waters()\"\n     style=\"width: 115px;\"> مجـــموعه آبـــی </button>\n</li>\n\n<li class=\"nav-item m-2\">\n    <img (click)=\"hotels()\"  src=\"https://golestankooh.com/apppictures/facilities/2.png\" style=\"width: 60px; cursor: pointer;\">\n    <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1\" (click)=\"hotels()\" \n    style=\"width: 98px;\" >عمارت چلچراغ</button>\n</li>\n\n<li class=\"nav-item m-2\">\n    <img  (click)=\"gotosuites()\" src=\"https://golestankooh.com/apppictures/facilities/3.png\" style=\"width: 60px; cursor: pointer;\">\n    <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1\"\n     style=\"width: 120px;\" (click)=\"gotosuites()\">مهمانکده دهکده </button>\n</li>\n</div>\n\n<div class=\"home-detailes-style-mobile \" dir=\"rtl\">\n<li class=\"nav-item m-2\">\n    <img  (click)=\"burritoRestaurant()\" src=\"https://golestankooh.com/apppictures/facilities/4.png\" style=\"width: 60px; cursor: pointer;\">\n    \n    <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 me-1 bashgah\"\n     style=\"width: 98px; margin-left: 2px;\" (click)=\"burritoRestaurant()\"> رستوران بوریتو</button>\n    \n</li>\n<li class=\"nav-item m-2\">\n    <img  (click)=\"sportGrounds()\" src=\"https://golestankooh.com/apppictures/facilities/5.png\" style=\"width: 60px; cursor: pointer;\">\n    \n    <button class=\"  mt-1 btn home-detailes-style-mobile home-detailes-style1 \" \n    style=\"width: 110px;\" (click)=\"sportGrounds()\">زمین های ورزشی </button>\n    \n</li>\n<li class=\"nav-item text-center m-2\">\n    <img (click)=\"traditionalRestaurant()\" src=\"https://golestankooh.com/apppictures/facilities/6.png\" style=\"width: 60px; cursor: pointer;\">\n    \n    <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 \"\n     style=\"width: 98px; margin-left: 5px;\"  (click)=\"traditionalRestaurant()\"> باغ رستوران نابره \n\n    </button>\n</li>\n</div>\n\n<div class=\"home-detailes-style-mobile \" dir=\"rtl\">\n<li class=\"nav-item m-2\">\n  <img (click)=\"hall()\" src=\"https://golestankooh.com/apppictures/facilities/7.png\" style=\"width: 60px; cursor: pointer;\">\n  \n  <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 me-1 bashgah\"\n   style=\"width: 110px; margin-left: 2px;\" (click)=\"hall()\"> تـــــــــالار</button>\n  \n</li>\n<li class=\"nav-item m-2\">\n  <img  (click)=\"pantry()\" src=\"https://golestankooh.com/apppictures/facilities/8.png\" style=\"width: 60px; cursor: pointer;\">\n  \n  <button class=\"mt-1 btn home-detailes-style-mobile home-detailes-style1\"\n  style=\"width: 98px;\" (click)=\"pantry()\">شــربـت خــانـه </button>\n  \n</li>\n<li class=\"nav-item text-center m-2\">\n  <img (click)=\"coffe()\" src=\"https://golestankooh.com/apppictures/facilities/9.png\" style=\"width: 60px; cursor: pointer;\">\n  \n  <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 \"\n   style=\"width: 115px; margin-left: 5px;\"  (click)=\"coffe()\"> کــــافی شـــاپ\n\n  </button>\n</li>\n</div>\n\n\n<div class=\"home-detailes-style-mobile \" dir=\"rtl\">\n<li class=\"nav-item m-2\">\n<img (click)=\"deli()\" src=\"https://golestankooh.com/apppictures/facilities/13.png\" style=\"width: 60px;  margin-left: 8px; cursor: pointer;\">\n\n<button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 me-1 bashgah\" \nstyle=\"width: 95px; margin-left: 8px;\" (click)=\"deli()\"> گلستانفود</button>\n\n</li>\n\n<li class=\"nav-item m-2\">\n<img  (click)=\"bazaar()\" src=\"https://golestankooh.com/apppictures/facilities/11.png\" style=\"width: 60px; margin-left: 13px; cursor: pointer;\">\n\n<button class=\"  mt-1 btn home-detailes-style-mobile home-detailes-style1 \"\n style=\"width: 98px; margin-left: 13px;\"   (click)=\"bazaar()\">بـــــازارچـــــه  </button>\n\n</li>\n\n\n<li class=\"nav-item text-center m-2\">\n<img  (click)=\"greenhouses()\" src=\"https://golestankooh.com/apppictures/facilities/12.png\" style=\"width: 60px; cursor: pointer;\">\n\n<button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 \"\n style=\"width: 98px; \" (click)=\"greenhouses()\"> گــــلخـــــانــه\n\n</button>\n</li>\n\n</div>\n\n\n<div class=\"home-detailes-style-mobile \" dir=\"rtl\">\n<li class=\"nav-item text-center m-2\">\n<img  (click)=\"gameCenter()\" src=\"https://golestankooh.com/apppictures/facilities/10.png\" style=\"width: 60px; cursor: pointer;\">\n\n<button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 \"\nstyle=\"width: 115px;\"  (click)=\"gameCenter()\"> گیم سنتر\n\n</button>\n</li>\n\n<li class=\"nav-item text-center m-2\">\n  <img  (click)=\"royalsuits()\" src=\"https://golestankooh.com/apppictures/facilities/3.png\" style=\"width: 60px; cursor: pointer;\">\n  \n  <button class=\" mt-1 btn home-detailes-style-mobile home-detailes-style1 \"\n  style=\"width: 115px;\"  (click)=\"royalsuits()\"> سوییت های vip\n  \n  </button>\n  </li>\n</div>\n\n\n      </ion-card>\n      \n    </div>\n\n\n<app-mainfooter></app-mainfooter>\n    \n    </div>\n    </div>  \n    </div>\n\n</ion-content>\n";

/***/ })

}]);
//# sourceMappingURL=src_app_facilities_facilities_module_ts.js.map