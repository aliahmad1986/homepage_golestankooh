"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_mainfooter_mainfooter_module_ts"],{

/***/ 48236:
/*!****************************************************!*\
  !*** ./src/app/mainfooter/Mainfooter.component.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainfooterComponent": () => (/* binding */ MainfooterComponent)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _mainfooter_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./mainfooter.component.html?ngResource */ 30119);
/* harmony import */ var _mainfooter_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./mainfooter.component.scss?ngResource */ 51336);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);




let MainfooterComponent = class MainfooterComponent {
    constructor() { }
    ngOnInit() { }
};
MainfooterComponent.ctorParameters = () => [];
MainfooterComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-mainfooter',
        template: _mainfooter_component_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_mainfooter_component_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], MainfooterComponent);



/***/ }),

/***/ 20890:
/*!*************************************************!*\
  !*** ./src/app/mainfooter/mainfooter.module.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MainfooterCModule": () => (/* binding */ MainfooterCModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _Mainfooter_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Mainfooter.component */ 48236);






let MainfooterCModule = class MainfooterCModule {
};
MainfooterCModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_3__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.IonicModule
        ],
        declarations: [_Mainfooter_component__WEBPACK_IMPORTED_MODULE_0__.MainfooterComponent],
        exports: [_Mainfooter_component__WEBPACK_IMPORTED_MODULE_0__.MainfooterComponent]
    })
], MainfooterCModule);



/***/ }),

/***/ 51336:
/*!*****************************************************************!*\
  !*** ./src/app/mainfooter/mainfooter.component.scss?ngResource ***!
  \*****************************************************************/
/***/ ((module) => {

module.exports = ".footermain {\n  background-image: url(\"https://golestankooh.com/apppictures/footerback.png\");\n  height: 100px;\n  background-size: 100%;\n  margin-top: -13px;\n  margin-bottom: -229%;\n  column-count: 3;\n  background-repeat: no-repeat;\n  z-index: 5;\n}\n\n@media screen and (min-width: 1550px) {\n  .footermain {\n    height: 130px;\n  }\n}\n\n@media screen and (min-width: 1550px) {\n  .footertext {\n    margin-top: 50px;\n  }\n}\n\n.footertext {\n  margin-right: 80px;\n  margin-top: 12%;\n  color: white;\n  width: 100%;\n  font-size: 14px;\n  margin-bottom: -50px;\n  z-index: 5;\n}\n\n.tripads {\n  width: 170px;\n  height: 30px;\n  margin-top: 45px;\n  margin-bottom: -10px;\n  margin-right: 5%;\n  margin-left: 19%;\n  cursor: pointer;\n  z-index: 5;\n}\n\n.footerlink1 {\n  width: 150px;\n  height: 30px;\n  margin-top: 8%;\n  margin-right: 6%;\n  cursor: pointer;\n  z-index: 5;\n}\n\n.footerlink2 {\n  width: 150px;\n  height: 30px;\n  margin-top: 11.5%;\n  cursor: pointer;\n}\n\n@media screen and (max-width: 1200px) {\n  .footermain {\n    visibility: hidden;\n    margin-bottom: 0px;\n  }\n}\n\n@media screen and (max-width: 1200px) {\n  .footertext {\n    visibility: hidden;\n  }\n}\n\n@media screen and (max-width: 1200px) {\n  .footerlink {\n    width: 200px;\n    height: 38px;\n    margin-top: 10%;\n    margin-right: 10%;\n    margin-bottom: 0;\n    cursor: pointer;\n    z-index: 5;\n  }\n}\n\n@media screen and (max-width: 1200px) {\n  .tripads {\n    width: 190px;\n    height: 28px;\n    margin-top: 25px;\n    margin-right: 0;\n    margin-left: 0;\n    margin-bottom: -50px;\n    cursor: pointer;\n    z-index: 5;\n  }\n}\n\n@media screen and (max-width: 1200px) {\n  .footermainmobile {\n    background-image: url(\"https://golestankooh.com/apppictures/footerbackmobile1.png\");\n    height: 80px;\n    background-size: 100%;\n    background-repeat: no-repeat;\n    display: flex;\n    padding-right: 8%;\n    padding-left: 9%;\n  }\n}\n\n@media screen and (min-width: 1200px) {\n  .footermainmobile {\n    visibility: hidden;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW5mb290ZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw0RUFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSxVQUFBO0FBQ0Y7O0FBQ0E7RUFDRTtJQUNFLGFBQUE7RUFFRjtBQUNGOztBQUVBO0VBQ0U7SUFDRSxnQkFBQTtFQUFGO0FBQ0Y7O0FBS0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGVBQUE7RUFDQSxvQkFBQTtFQUNBLFVBQUE7QUFIRjs7QUFNQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQUhGOztBQU1BO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsVUFBQTtBQUhGOztBQU1BO0VBQ0UsWUFBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFIRjs7QUFNQTtFQUNFO0lBQ0Esa0JBQUE7SUFDQSxrQkFBQTtFQUhBO0FBQ0Y7O0FBTUE7RUFDRTtJQUNFLGtCQUFBO0VBSkY7QUFDRjs7QUFPQTtFQUNFO0lBQ0UsWUFBQTtJQUNBLFlBQUE7SUFDQSxlQUFBO0lBQ0EsaUJBQUE7SUFDQSxnQkFBQTtJQUNBLGVBQUE7SUFDQSxVQUFBO0VBTEY7QUFDRjs7QUFRQTtFQUNFO0lBQ0UsWUFBQTtJQUNBLFlBQUE7SUFDQSxnQkFBQTtJQUNBLGVBQUE7SUFDQSxjQUFBO0lBQ0Esb0JBQUE7SUFDQSxlQUFBO0lBQ0EsVUFBQTtFQU5GO0FBQ0Y7O0FBU0E7RUFDRTtJQUNBLG1GQUFBO0lBQ0EsWUFBQTtJQUNBLHFCQUFBO0lBQ0EsNEJBQUE7SUFDQSxhQUFBO0lBQ0EsaUJBQUE7SUFDQSxnQkFBQTtFQVBBO0FBQ0Y7O0FBV0E7RUFDRTtJQUNFLGtCQUFBO0VBVEY7QUFDRiIsImZpbGUiOiJtYWluZm9vdGVyLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmZvb3Rlcm1haW4ge1xyXG4gIGJhY2tncm91bmQtaW1hZ2U6dXJsKCdodHRwczovL2dvbGVzdGFua29vaC5jb20vYXBwcGljdHVyZXMvZm9vdGVyYmFjay5wbmcnKTtcclxuICBoZWlnaHQ6IDEwMHB4O1xyXG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJTsgXHJcbiAgbWFyZ2luLXRvcDogLTEzcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogLTIyOSU7XHJcbiAgY29sdW1uLWNvdW50OiAzO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgei1pbmRleDogNTtcclxufVxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWluLXdpZHRoOiAxNTUwcHgpIHtcclxuICAuZm9vdGVybWFpbntcclxuICAgIGhlaWdodDogMTMwcHg7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTU1MHB4KSB7XHJcbiAgLmZvb3RlcnRleHR7XHJcbiAgICBtYXJnaW4tdG9wOiA1MHB4O1xyXG5cclxuICB9XHJcblxyXG59XHJcblxyXG4uZm9vdGVydGV4dHtcclxuICBtYXJnaW4tcmlnaHQ6IDgwcHg7XHJcbiAgbWFyZ2luLXRvcDogMTIlO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogLTUwcHg7XHJcbiAgei1pbmRleDogNTtcclxufVxyXG5cclxuLnRyaXBhZHMge1xyXG4gIHdpZHRoOiAxNzBweDtcclxuICBoZWlnaHQ6IDMwcHg7XHJcbiAgbWFyZ2luLXRvcDogNDVweDtcclxuICBtYXJnaW4tYm90dG9tOiAtMTBweDtcclxuICBtYXJnaW4tcmlnaHQ6IDUlO1xyXG4gIG1hcmdpbi1sZWZ0OiAxOSU7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIHotaW5kZXg6IDU7XHJcbn1cclxuXHJcbi5mb290ZXJsaW5rMSB7XHJcbiAgd2lkdGg6IDE1MHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBtYXJnaW4tdG9wOiA4JTtcclxuICBtYXJnaW4tcmlnaHQ6IDYlO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICB6LWluZGV4OiA1O1xyXG59XHJcblxyXG4uZm9vdGVybGluazJ7XHJcbiAgd2lkdGg6IDE1MHB4O1xyXG4gIGhlaWdodDogMzBweDtcclxuICBtYXJnaW4tdG9wOiAxMS41JTtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gIC5mb290ZXJtYWluIHtcclxuICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xyXG4gIH1cclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTIwMHB4KSB7XHJcbiAgLmZvb3RlcnRleHQge1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIH1cclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMTIwMHB4KSB7XHJcbiAgLmZvb3Rlcmxpbmt7XHJcbiAgICB3aWR0aDogMjAwcHg7XHJcbiAgICBoZWlnaHQ6IDM4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMCU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwJTtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICB6LWluZGV4OiA1OyAgXHJcbiAgfVxyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOiAxMjAwcHgpIHtcclxuICAudHJpcGFkc3tcclxuICAgIHdpZHRoOiAxOTBweDtcclxuICAgIGhlaWdodDogMjhweDtcclxuICAgIG1hcmdpbi10b3A6IDI1cHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDA7XHJcbiAgICBtYXJnaW4tbGVmdDogMDtcclxuICAgIG1hcmdpbi1ib3R0b206IC01MHB4O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgei1pbmRleDogNTtcclxuICB9XHJcbn1cclxuXHJcbkBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDEyMDBweCkge1xyXG4gIC5mb290ZXJtYWlubW9iaWxlIHtcclxuICBiYWNrZ3JvdW5kLWltYWdlOnVybCgnaHR0cHM6Ly9nb2xlc3Rhbmtvb2guY29tL2FwcHBpY3R1cmVzL2Zvb3RlcmJhY2ttb2JpbGUxLnBuZycpO1xyXG4gIGhlaWdodDogODBweDtcclxuICBiYWNrZ3JvdW5kLXNpemU6IDEwMCU7XHJcbiAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIHBhZGRpbmctcmlnaHQ6IDglO1xyXG4gIHBhZGRpbmctbGVmdDogOSU7XHJcblxyXG4gIH1cclxufVxyXG5cclxuQG1lZGlhIHNjcmVlbiBhbmQgKG1pbi13aWR0aDogMTIwMHB4KSB7XHJcbiAgLmZvb3Rlcm1haW5tb2JpbGUge1xyXG4gICAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIH0gIFxyXG4gIH0iXX0= */";

/***/ }),

/***/ 30119:
/*!*****************************************************************!*\
  !*** ./src/app/mainfooter/mainfooter.component.html?ngResource ***!
  \*****************************************************************/
/***/ ((module) => {

module.exports = "<div class=\"footermain\" dir=\"rtl\">\n    <p class=\"footertext\">تمامی حقوق این وب اپلیکیشن متعلق به شرکت گلستان سرچشمه خوانسار میباشد.</p>\n\n    <a href=\"https://trustseal.enamad.ir/?id=486120&Code=skimTwPbqHAuM1Suim11LakYfrvZftzE\" target=\"_blank\">\n      <img src=\"https://golestankooh.com/apppictures/logoenamad.png\" style=\"width: 60px; margin-right: 38%; margin-top: 8%;\"></a>\n      <a href=\"tel:+983157799500\">\n    <img class=\"footerlink1\" src=\"https://golestankooh.com/apppictures/footerlink1.png\" alt=”phone” />\n    </a>\n    <a href=\"https://www.instagram.com/golestankooh_org?igsh=MWozcGsxcWt0Y3ZicQ==\" target=\"_blank\">\n      <img class=\"footerlink2\" src=\"https://golestankooh.com/apppictures/footerlink2.png\" alt=”insta” />\n      </a>\n    <a href=\"https://www.tripadvisor.com/Hotel_Review-g8365902-d25323313-Reviews-Golestankooh-Khansar_Isfahan_Province.html\" target=\"_blank\">\n    <img class=\"tripads\" src=\"https://golestankooh.com/apppictures/trip.png\" alt=\"trip\" />\n    </a>\n</div>\n\n<div class=\"footermainmobile\" dir=\"rtl\">\n    <a href=\"https://trustseal.enamad.ir/?id=486120&Code=skimTwPbqHAuM1Suim11LakYfrvZftzE\" target=\"_blank\">\n    <img class=\"\" src=\"https://golestankooh.com/apppictures/logoenamad.png\" style=\"width: 50px; margin-top: 45%;\"></a>\n    <a href=\"tel:+983157799500\">\n    <img class=\"footerlink1\" src=\"https://golestankooh.com/apppictures/footerlink1.png\" alt=”phone” style=\"width: 95%; height: 30%; margin-top: 48%;\"/>\n    </a>\n    <a href=\"https://www.instagram.com/golestankooh_org?igsh=MWozcGsxcWt0Y3ZicQ==\" target=\"_blank\">\n      <img class=\"footerlink2\" src=\"https://golestankooh.com/apppictures/footerlink2.png\" alt=”insta” style= \"width: 90%; height: 30%; margin-top: 32%;\"/>\n      </a>\n    <a href=\"https://www.tripadvisor.com/Hotel_Review-g8365902-d25323313-Reviews-Golestankooh-Khansar_Isfahan_Province.html\" target=\"_blank\">\n    <img class=\"\" src=\"https://golestankooh.com/apppictures/trip.png\" alt=\"trip\"  style=\"width: 90%; height: 38%; margin-top: 30%;\"/>\n    </a>\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_mainfooter_mainfooter_module_ts.js.map