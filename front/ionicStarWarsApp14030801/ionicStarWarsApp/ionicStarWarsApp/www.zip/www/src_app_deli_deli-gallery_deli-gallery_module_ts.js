"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_deli_deli-gallery_deli-gallery_module_ts"],{

/***/ 24000:
/*!******************************************************************!*\
  !*** ./src/app/deli/deli-gallery/deli-gallery-routing.module.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeliGalleryPageRoutingModule": () => (/* binding */ DeliGalleryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _deli_gallery_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deli-gallery.page */ 95744);




const routes = [
    {
        path: '',
        component: _deli_gallery_page__WEBPACK_IMPORTED_MODULE_0__.DeliGalleryPage
    }
];
let DeliGalleryPageRoutingModule = class DeliGalleryPageRoutingModule {
};
DeliGalleryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DeliGalleryPageRoutingModule);



/***/ }),

/***/ 11863:
/*!**********************************************************!*\
  !*** ./src/app/deli/deli-gallery/deli-gallery.module.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeliGalleryPageModule": () => (/* binding */ DeliGalleryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _deli_gallery_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deli-gallery-routing.module */ 24000);
/* harmony import */ var _deli_gallery_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./deli-gallery.page */ 95744);







let DeliGalleryPageModule = class DeliGalleryPageModule {
};
DeliGalleryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _deli_gallery_routing_module__WEBPACK_IMPORTED_MODULE_0__.DeliGalleryPageRoutingModule
        ],
        declarations: [_deli_gallery_page__WEBPACK_IMPORTED_MODULE_1__.DeliGalleryPage]
    })
], DeliGalleryPageModule);



/***/ }),

/***/ 95744:
/*!********************************************************!*\
  !*** ./src/app/deli/deli-gallery/deli-gallery.page.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DeliGalleryPage": () => (/* binding */ DeliGalleryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _deli_gallery_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./deli-gallery.page.html?ngResource */ 71219);
/* harmony import */ var _deli_gallery_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./deli-gallery.page.scss?ngResource */ 332);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);




let DeliGalleryPage = class DeliGalleryPage {
    constructor() { }
    ngOnInit() {
    }
};
DeliGalleryPage.ctorParameters = () => [];
DeliGalleryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-deli-gallery',
        template: _deli_gallery_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_deli_gallery_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], DeliGalleryPage);



/***/ }),

/***/ 332:
/*!*********************************************************************!*\
  !*** ./src/app/deli/deli-gallery/deli-gallery.page.scss?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = ".thumbs {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  margin-top: 5%;\n  margin-right: 150px;\n  margin-left: 150px;\n  max-width: 100%;\n}\n.thumbs > a {\n  max-width: 380px;\n  height: 180px;\n  margin: 10px;\n  overflow: hidden;\n  border-radius: 15px;\n  box-shadow: 0 0 0 0px white, 0 4px 7px 3px rgba(0, 0, 0, 0.1);\n}\n.thumbs > a img {\n  transform: scale(1);\n  transition: transform 0.1s ease-in-out;\n  filter: grayscale(50%);\n  min-width: 100%;\n  min-height: 100%;\n  max-width: 100%;\n  max-height: 100%;\n}\n.thumbs > a:hover img {\n  transform: scale(1.1);\n  filter: grayscale(0%);\n}\n.lightbox {\n  z-index: 1;\n  position: fixed;\n  background: rgba(0, 0, 0, 0.5);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  height: 100%;\n  width: 100%;\n  left: 0;\n  top: 0;\n  transform: translateY(-100%);\n  opacity: 0;\n  transition: opacity 0.5s ease-in-out;\n}\n.lightbox:has(div:target) {\n  transform: translateY(0%);\n  opacity: 1;\n}\n.lightbox a.nav {\n  text-decoration: none;\n  color: white;\n  font-size: 40px;\n  text-shadow: 0 2px 2px rgba(0, 0, 0, 0.8);\n  opacity: 0.5;\n  font-weight: 200;\n}\n.lightbox a.nav:hover {\n  opacity: 1;\n}\n.lightbox .target {\n  position: absolute;\n  justify-content: center;\n  height: 100%;\n  width: 90%;\n  display: flex;\n  transform: scale(0);\n  align-items: center;\n  justify-content: space-between;\n}\n.lightbox .target *:first-child, .lightbox .target *:last-child {\n  flex: 0 0 100px;\n  text-align: center;\n}\n@media all and (max-width: 600px) {\n  .lightbox .target *:first-child, .lightbox .target *:last-child {\n    flex: 0 0 50px;\n  }\n}\n.lightbox .target .content {\n  transform: scale(0.9);\n  opacity: 0;\n  flex: 1 1 auto;\n  align-self: center;\n  max-height: 100%;\n  min-height: 0;\n  min-width: 0;\n  border-radius: 15px;\n  overflow: hidden;\n  box-shadow: 0 0 0 3px white, 0 5px 8px 3px rgba(0, 0, 0, 0.2);\n  transition: transform 0.25s ease-in-out, opacity 0.25s ease-in-out;\n}\n.lightbox .target .content img {\n  min-width: 100%;\n  min-height: 100%;\n  max-width: 100%;\n  max-height: calc(100vh - 40px);\n  display: block;\n  margin: 0;\n}\n.lightbox .target:target {\n  transform: scale(1);\n}\n.lightbox .target:target .content {\n  transform: scale(1);\n  opacity: 1;\n}\n.lightbox .close {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n}\n.button {\n  padding: 7px 10px;\n  display: inline-block;\n  text-decoration: none;\n  font-size: 15px;\n}\n.button-primary {\n  border: 2px solid black;\n  color: black;\n  border-radius: 15px;\n}\na.button-primary:hover {\n  background: #444;\n  color: white;\n}\na.button-primary:hover .switch-font:before {\n  content: \"\\f119\";\n}\na.button-secondary:hover {\n  background: #444;\n  border: 2px solid red;\n}\n.button-secondary {\n  background: black;\n  color: white;\n}\n.switch-font:before {\n  content: \"\\f007\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRlbGktZ2FsbGVyeS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBQ0o7QUFBSTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsNkRBQUE7QUFFTjtBQURNO0VBQ0UsbUJBQUE7RUFDQSxzQ0FBQTtFQUNBLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBR1I7QUFBUTtFQUNFLHFCQUFBO0VBQ0EscUJBQUE7QUFFVjtBQUlFO0VBQ0UsVUFBQTtFQUNBLGVBQUE7RUFDQSw4QkFBQTtFQUNBLDJCQUFBO0VBQ0EsbUNBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLE9BQUE7RUFDQSxNQUFBO0VBQ0EsNEJBQUE7RUFDQSxVQUFBO0VBQ0Esb0NBQUE7QUFESjtBQUVJO0VBQ0UseUJBQUE7RUFDQSxVQUFBO0FBQU47QUFFSTtFQUNFLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSx5Q0FBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUFOO0FBQ007RUFDRSxVQUFBO0FBQ1I7QUFFSTtFQUNFLGtCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EsOEJBQUE7QUFBTjtBQUNNO0VBQ0UsZUFBQTtFQUNBLGtCQUFBO0FBQ1I7QUFBUTtFQUhGO0lBSUksY0FBQTtFQUdSO0FBQ0Y7QUFETTtFQUNFLHFCQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUVBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsNkRBQUE7RUFDQSxrRUFBQTtBQUVSO0FBRFE7RUFDRSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsOEJBQUE7RUFDQSxjQUFBO0VBQ0EsU0FBQTtBQUdWO0FBQU07RUFDRSxtQkFBQTtBQUVSO0FBRFE7RUFDRSxtQkFBQTtFQUNBLFVBQUE7QUFHVjtBQUNJO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtBQUNOO0FBSUk7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FBREo7QUFJRTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FBREo7QUFJRTtFQUNFLGdCQUFBO0VBQ0EsWUFBQTtBQURKO0FBSUU7RUFDRyxnQkFBQTtBQURMO0FBSUU7RUFDRSxnQkFBQTtFQUNBLHFCQUFBO0FBREo7QUFNRTtFQUNFLGlCQUFBO0VBQ0EsWUFBQTtBQUhKO0FBUUU7RUFDRSxnQkFBQTtBQUxKIiwiZmlsZSI6ImRlbGktZ2FsbGVyeS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGh1bWJzIHtcclxuICAgIGRpc3BsYXk6ZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDpjZW50ZXI7XHJcbiAgICBmbGV4LXdyYXA6d3JhcDtcclxuICAgIG1hcmdpbi10b3A6IDUlO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxNTBweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAxNTBweDtcclxuICAgIG1heC13aWR0aDoxMDAlO1xyXG4gICAgPiBhIHtcclxuICAgICAgbWF4LXdpZHRoOjM4MHB4O1xyXG4gICAgICBoZWlnaHQ6MTgwcHg7XHJcbiAgICAgIG1hcmdpbjoxMHB4O1xyXG4gICAgICBvdmVyZmxvdzpoaWRkZW47XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6MTVweDtcclxuICAgICAgYm94LXNoYWRvdzowIDAgMCAwcHggd2hpdGUsIDAgNHB4IDdweCAzcHggcmdiYShibGFjaywgMC4xKTtcclxuICAgICAgaW1nIHtcclxuICAgICAgICB0cmFuc2Zvcm06c2NhbGUoMSk7XHJcbiAgICAgICAgdHJhbnNpdGlvbjp0cmFuc2Zvcm0gMC4xcyBlYXNlLWluLW91dDtcclxuICAgICAgICBmaWx0ZXI6Z3JheXNjYWxlKDUwJSk7XHJcbiAgICAgICAgbWluLXdpZHRoOjEwMCU7XHJcbiAgICAgICAgbWluLWhlaWdodDoxMDAlO1xyXG4gICAgICAgIG1heC13aWR0aDoxMDAlO1xyXG4gICAgICAgIG1heC1oZWlnaHQ6MTAwJTtcclxuICAgICAgfVxyXG4gICAgICAmOmhvdmVyIHtcclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgdHJhbnNmb3JtOnNjYWxlKDEuMSk7XHJcbiAgICAgICAgICBmaWx0ZXI6Z3JheXNjYWxlKDAlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgLmxpZ2h0Ym94IHtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBwb3NpdGlvbjpmaXhlZDtcclxuICAgIGJhY2tncm91bmQ6cmdiYShibGFjaywwLjUpO1xyXG4gICAgYmFja2Ryb3AtZmlsdGVyOmJsdXIoMTBweCk7XHJcbiAgICAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcjogYmx1cigxMHB4KTtcclxuICAgIGhlaWdodDoxMDAlO1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIGxlZnQ6MDtcclxuICAgIHRvcDowO1xyXG4gICAgdHJhbnNmb3JtOnRyYW5zbGF0ZVkoLTEwMCUpO1xyXG4gICAgb3BhY2l0eTowO1xyXG4gICAgdHJhbnNpdGlvbjpvcGFjaXR5IDAuNXMgZWFzZS1pbi1vdXQ7XHJcbiAgICAmOmhhcyhkaXY6dGFyZ2V0KSB7XHJcbiAgICAgIHRyYW5zZm9ybTp0cmFuc2xhdGVZKDAlKTtcclxuICAgICAgb3BhY2l0eToxO1xyXG4gICAgfVxyXG4gICAgYS5uYXYge1xyXG4gICAgICB0ZXh0LWRlY29yYXRpb246bm9uZTtcclxuICAgICAgY29sb3I6d2hpdGU7XHJcbiAgICAgIGZvbnQtc2l6ZTo0MHB4O1xyXG4gICAgICB0ZXh0LXNoYWRvdzowIDJweCAycHggcmdiYShibGFjaywwLjgpO1xyXG4gICAgICBvcGFjaXR5OjAuNTtcclxuICAgICAgZm9udC13ZWlnaHQ6MjAwO1xyXG4gICAgICAmOmhvdmVyIHtcclxuICAgICAgICBvcGFjaXR5OjE7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC50YXJnZXQge1xyXG4gICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIGhlaWdodDoxMDAlO1xyXG4gICAgICB3aWR0aDo5MCU7XHJcbiAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgdHJhbnNmb3JtOnNjYWxlKDApO1xyXG4gICAgICBhbGlnbi1pdGVtczpjZW50ZXI7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDpzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAqOmZpcnN0LWNoaWxkLCo6bGFzdC1jaGlsZCB7XHJcbiAgICAgICAgZmxleDowIDAgMTAwcHg7XHJcbiAgICAgICAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgQG1lZGlhIGFsbCBhbmQgKG1heC13aWR0aDo2MDBweCl7XHJcbiAgICAgICAgICBmbGV4OjAgMCA1MHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAuY29udGVudCB7XHJcbiAgICAgICAgdHJhbnNmb3JtOnNjYWxlKDAuOSk7XHJcbiAgICAgICAgb3BhY2l0eTowO1xyXG4gICAgICAgIGZsZXg6MSAxIGF1dG87XHJcbiAgICAgICAgYWxpZ24tc2VsZjogY2VudGVyO1xyXG4gICAgICAgIG1heC1oZWlnaHQ6MTAwJTtcclxuICAgICAgICBtaW4taGVpZ2h0OjA7XHJcbiAgICAgICAgLy8gbWF4LXdpZHRoOmNhbGMoMTAwJSAtIDIwMHB4KTtcclxuICAgICAgICBtaW4td2lkdGg6MDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOjE1cHg7XHJcbiAgICAgICAgb3ZlcmZsb3c6aGlkZGVuO1xyXG4gICAgICAgIGJveC1zaGFkb3c6MCAwIDAgM3B4IHdoaXRlLCAwIDVweCA4cHggM3B4IHJnYmEoYmxhY2ssIDAuMik7XHJcbiAgICAgICAgdHJhbnNpdGlvbjp0cmFuc2Zvcm0gMC4yNXMgZWFzZS1pbi1vdXQsb3BhY2l0eSAwLjI1cyBlYXNlLWluLW91dDtcclxuICAgICAgICBpbWcge1xyXG4gICAgICAgICAgbWluLXdpZHRoOjEwMCU7XHJcbiAgICAgICAgICBtaW4taGVpZ2h0OjEwMCU7XHJcbiAgICAgICAgICBtYXgtd2lkdGg6MTAwJTtcclxuICAgICAgICAgIG1heC1oZWlnaHQ6Y2FsYygxMDB2aCAtIDQwcHgpO1xyXG4gICAgICAgICAgZGlzcGxheTpibG9jaztcclxuICAgICAgICAgIG1hcmdpbjowO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICAmOnRhcmdldCB7XHJcbiAgICAgICAgdHJhbnNmb3JtOnNjYWxlKDEpO1xyXG4gICAgICAgIC5jb250ZW50IHtcclxuICAgICAgICAgIHRyYW5zZm9ybTpzY2FsZSgxKTtcclxuICAgICAgICAgIG9wYWNpdHk6MTtcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC5jbG9zZSB7XHJcbiAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICByaWdodDoxMHB4O1xyXG4gICAgICB0b3A6MTBweDtcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICAgIC5idXR0b24ge1xyXG4gICAgcGFkZGluZzogN3B4IDEwcHg7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIC5idXR0b24tcHJpbWFyeSB7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCBibGFjaztcclxuICAgIGNvbG9yOiBibGFjaztcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgfVxyXG4gIFxyXG4gIGEuYnV0dG9uLXByaW1hcnk6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogIzQ0NDtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICB9XHJcbiAgXHJcbiAgYS5idXR0b24tcHJpbWFyeTpob3ZlciAuc3dpdGNoLWZvbnQ6YmVmb3JlIHtcclxuICAgICBjb250ZW50OiBcIlxcZjExOVwiO1xyXG4gIH0gXHJcbiAgXHJcbiAgYS5idXR0b24tc2Vjb25kYXJ5OmhvdmVyIHtcclxuICAgIGJhY2tncm91bmQ6ICM0NDQ7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCByZWQ7XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIC5idXR0b24tc2Vjb25kYXJ5IHtcclxuICAgIGJhY2tncm91bmQ6IGJsYWNrO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICBcclxuICBcclxuICBcclxuICAuc3dpdGNoLWZvbnQ6YmVmb3JlIHtcclxuICAgIGNvbnRlbnQ6IFwiXFxmMDA3XCI7XHJcbiAgfSAiXX0= */";

/***/ }),

/***/ 71219:
/*!*********************************************************************!*\
  !*** ./src/app/deli/deli-gallery/deli-gallery.page.html?ngResource ***!
  \*********************************************************************/
/***/ ((module) => {

module.exports = "<ion-content  overflow-scroll=\"false\" >\n  <div class=\"thumbs\">\n    \n    <a href=\"#target1\"><img src='https://golestankooh.com/apppictures/deli/1.jpg' alt=''></a>\n    <a href=\"#target2\"><img src='https://golestankooh.com/apppictures/deli/2.jpg' alt=''></a>\n    <a href=\"#target3\"><img src='https://golestankooh.com/apppictures/deli/3.jpg' alt=''></a>\n    <a href=\"#target4\"><img src='https://golestankooh.com/apppictures/deli/4.JPG' alt=''></a>\n    <a href=\"#target5\"><img src='https://golestankooh.com/apppictures/deli/5.JPG' alt=''></a>\n    <a href=\"#target6\"><img src='https://golestankooh.com/apppictures/deli/6.JPG' alt=''></a>\n    <a href=\"#target7\"><img src='https://golestankooh.com/apppictures/deli/7.jpg' alt=''></a>\n    <a href=\"#target8\"><img src='https://golestankooh.com/apppictures/deli/8.jpg' alt=''></a>\n    <a href=\"#target9\"><img src='https://golestankooh.com/apppictures/deli/9.jpg' alt=''></a>\n    <a href=\"#target10\"><img src='https://golestankooh.com/apppictures/deli/10.JPG' alt=''></a>\n    <a href=\"#target11\"><img src='https://golestankooh.com/apppictures/deli/11.JPG' alt=''></a>\n    <a href=\"#target12\"><img src='https://golestankooh.com/apppictures/deli/12.JPG' alt=''></a>\n  \n  \n  \n  \n  </div>\n  \n  <div class=\"lightbox\">\n    <div class=\"target\" id=\"target1\">\n      <div class=\"content\">\n        <img src='https://golestankooh.com/apppictures/deli/1.jpg' alt=''>\n      </div>\n      <a href=\"#target2\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target2\">\n      <a href=\"#target1\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/2.jpg\" alt=''></div>\n        <a href=\"#target3\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target3\">\n      <a href=\"#target2\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\"><img src='https://golestankooh.com/apppictures/deli/3.jpg' alt=''></div>\n      <a href=\"#target4\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target4\">\n      <a href=\"#target3\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/4.JPG\" alt=''></div>\n        <a href=\"#target5\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target5\">\n      <a href=\"#target4\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/5.JPG\" alt=''></div>\n        <a href=\"#target6\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target6\">\n      <a href=\"#target5\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/6.JPG\" alt=''></div>\n        <a href=\"#target7\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target7\">\n      <a href=\"#target6\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/7.jpg\" alt=''></div>\n        <a href=\"#target8\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target8\">\n      <a href=\"#target7\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/8.jpg\" alt=''></div>\n        <a href=\"#target9\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target9\">\n      <a href=\"#target8\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/9.jpg\" alt=''></div>\n        <a href=\"#target10\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target10\">\n      <a href=\"#target9\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/10.JPG\" alt=''></div>\n        <a href=\"#target11\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target11\">\n      <a href=\"#target10\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/11.JPG\" alt=''></div>\n        <a href=\"#target12\" title=\"next\"><img src='https://golestankooh.com/apppictures/right.png' alt='' style=\"width: 50px;\"></a>\n    </div>\n    <div class=\"target\" id=\"target12\">\n      <a href=\"#target11\" title=\"previous\"><img src='https://golestankooh.com/apppictures/left.png' alt='' style=\"width: 50px;\"></a>\n      <div class=\"content\">\n        <img src=\"https://golestankooh.com/apppictures/deli/12.JPG\" alt=''></div>\n    </div>\n  \n  \n  \n\n    \n\n    \n    <a href=\"#!\" class=\"close nav\"><img src='https://golestankooh.com/apppictures/exit.png' alt='' style=\"width: 25px;\"></a>\n  </div>";

/***/ })

}]);
//# sourceMappingURL=src_app_deli_deli-gallery_deli-gallery_module_ts.js.map