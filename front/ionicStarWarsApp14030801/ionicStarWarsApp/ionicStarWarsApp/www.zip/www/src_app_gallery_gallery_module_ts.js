"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_gallery_gallery_module_ts"],{

/***/ 56059:
/*!***************************************************!*\
  !*** ./src/app/gallery/gallery-routing.module.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GalleryPageRoutingModule": () => (/* binding */ GalleryPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _gallery_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gallery.page */ 18526);




const routes = [
    {
        path: '',
        component: _gallery_page__WEBPACK_IMPORTED_MODULE_0__.GalleryPage
    }
];
let GalleryPageRoutingModule = class GalleryPageRoutingModule {
};
GalleryPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], GalleryPageRoutingModule);



/***/ }),

/***/ 18632:
/*!*******************************************!*\
  !*** ./src/app/gallery/gallery.module.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GalleryPageModule": () => (/* binding */ GalleryPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _gallery_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gallery-routing.module */ 56059);
/* harmony import */ var _gallery_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gallery.page */ 18526);







let GalleryPageModule = class GalleryPageModule {
};
GalleryPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _gallery_routing_module__WEBPACK_IMPORTED_MODULE_0__.GalleryPageRoutingModule
        ],
        declarations: [_gallery_page__WEBPACK_IMPORTED_MODULE_1__.GalleryPage]
    })
], GalleryPageModule);



/***/ }),

/***/ 18526:
/*!*****************************************!*\
  !*** ./src/app/gallery/gallery.page.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GalleryPage": () => (/* binding */ GalleryPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _gallery_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./gallery.page.html?ngResource */ 4050);
/* harmony import */ var _gallery_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./gallery.page.scss?ngResource */ 6121);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);




let GalleryPage = class GalleryPage {
    constructor() { }
    ngOnInit() {
    }
};
GalleryPage.ctorParameters = () => [];
GalleryPage = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Component)({
        selector: 'app-gallery',
        template: _gallery_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_gallery_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], GalleryPage);



/***/ }),

/***/ 6121:
/*!******************************************************!*\
  !*** ./src/app/gallery/gallery.page.scss?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = ".thumbs {\n  display: flex;\n  justify-content: center;\n  flex-wrap: wrap;\n  margin-top: 5%;\n  margin-right: 150px;\n  margin-left: 150px;\n  max-width: 100%;\n}\n.thumbs > a {\n  max-width: 380px;\n  height: 180px;\n  margin: 10px;\n  overflow: hidden;\n  border-radius: 15px;\n  box-shadow: 0 0 0 0px white, 0 4px 7px 3px rgba(0, 0, 0, 0.1);\n}\n.thumbs > a img {\n  transform: scale(1);\n  transition: transform 0.1s ease-in-out;\n  filter: grayscale(50%);\n  min-width: 100%;\n  min-height: 100%;\n  max-width: 100%;\n  max-height: 100%;\n}\n.thumbs > a:hover img {\n  transform: scale(1.1);\n  filter: grayscale(0%);\n}\n.lightbox {\n  z-index: 1;\n  position: fixed;\n  background: rgba(0, 0, 0, 0.5);\n  backdrop-filter: blur(10px);\n  -webkit-backdrop-filter: blur(10px);\n  height: 100%;\n  width: 100%;\n  left: 0;\n  top: 0;\n  transform: translateY(-100%);\n  opacity: 0;\n  transition: opacity 0.5s ease-in-out;\n}\n.lightbox:has(div:target) {\n  transform: translateY(0%);\n  opacity: 1;\n}\n.lightbox a.nav {\n  text-decoration: none;\n  color: white;\n  font-size: 40px;\n  text-shadow: 0 2px 2px rgba(0, 0, 0, 0.8);\n  opacity: 0.5;\n  font-weight: 200;\n}\n.lightbox a.nav:hover {\n  opacity: 1;\n}\n.lightbox .target {\n  position: absolute;\n  justify-content: center;\n  height: 100%;\n  width: 90%;\n  display: flex;\n  transform: scale(0);\n  align-items: center;\n  justify-content: space-between;\n}\n.lightbox .target *:first-child, .lightbox .target *:last-child {\n  flex: 0 0 100px;\n  text-align: center;\n}\n@media all and (max-width: 600px) {\n  .lightbox .target *:first-child, .lightbox .target *:last-child {\n    flex: 0 0 50px;\n  }\n}\n.lightbox .target .content {\n  transform: scale(0.9);\n  opacity: 0;\n  flex: 1 1 auto;\n  align-self: center;\n  max-height: 100%;\n  min-height: 0;\n  min-width: 0;\n  border-radius: 15px;\n  overflow: hidden;\n  box-shadow: 0 0 0 3px white, 0 5px 8px 3px rgba(0, 0, 0, 0.2);\n  transition: transform 0.25s ease-in-out, opacity 0.25s ease-in-out;\n}\n.lightbox .target .content img {\n  min-width: 100%;\n  min-height: 100%;\n  max-width: 100%;\n  max-height: calc(100vh - 40px);\n  display: block;\n  margin: 0;\n}\n.lightbox .target:target {\n  transform: scale(1);\n}\n.lightbox .target:target .content {\n  transform: scale(1);\n  opacity: 1;\n}\n.lightbox .close {\n  position: absolute;\n  right: 10px;\n  top: 10px;\n}\n.button {\n  padding: 7px 10px;\n  display: inline-block;\n  text-decoration: none;\n  font-size: 15px;\n}\n.button-primary {\n  border: 2px solid black;\n  color: black;\n  border-radius: 15px;\n}\na.button-primary:hover {\n  background: #444;\n  color: white;\n}\na.button-primary:hover .switch-font:before {\n  content: \"\\f119\";\n}\na.button-secondary:hover {\n  background: #444;\n  border: 2px solid red;\n}\n.button-secondary {\n  background: black;\n  color: white;\n}\n.switch-font:before {\n  content: \"\\f007\";\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImdhbGxlcnkucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksYUFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUNKO0FBQUk7RUFDRSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLDZEQUFBO0FBRU47QUFETTtFQUNFLG1CQUFBO0VBQ0Esc0NBQUE7RUFDQSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQUdSO0FBQVE7RUFDRSxxQkFBQTtFQUNBLHFCQUFBO0FBRVY7QUFJRTtFQUNFLFVBQUE7RUFDQSxlQUFBO0VBQ0EsOEJBQUE7RUFDQSwyQkFBQTtFQUNBLG1DQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxPQUFBO0VBQ0EsTUFBQTtFQUNBLDRCQUFBO0VBQ0EsVUFBQTtFQUNBLG9DQUFBO0FBREo7QUFFSTtFQUNFLHlCQUFBO0VBQ0EsVUFBQTtBQUFOO0FBRUk7RUFDRSxxQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EseUNBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUFBTjtBQUNNO0VBQ0UsVUFBQTtBQUNSO0FBRUk7RUFDRSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FBQU47QUFDTTtFQUNFLGVBQUE7RUFDQSxrQkFBQTtBQUNSO0FBQVE7RUFIRjtJQUlJLGNBQUE7RUFHUjtBQUNGO0FBRE07RUFDRSxxQkFBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFFQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLDZEQUFBO0VBQ0Esa0VBQUE7QUFFUjtBQURRO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLDhCQUFBO0VBQ0EsY0FBQTtFQUNBLFNBQUE7QUFHVjtBQUFNO0VBQ0UsbUJBQUE7QUFFUjtBQURRO0VBQ0UsbUJBQUE7RUFDQSxVQUFBO0FBR1Y7QUFDSTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7QUFDTjtBQUlJO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQURKO0FBSUU7RUFDRSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQURKO0FBSUU7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFESjtBQUlFO0VBQ0csZ0JBQUE7QUFETDtBQUlFO0VBQ0UsZ0JBQUE7RUFDQSxxQkFBQTtBQURKO0FBTUU7RUFDRSxpQkFBQTtFQUNBLFlBQUE7QUFISjtBQVFFO0VBQ0UsZ0JBQUE7QUFMSiIsImZpbGUiOiJnYWxsZXJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50aHVtYnMge1xyXG4gICAgZGlzcGxheTpmbGV4O1xyXG4gICAganVzdGlmeS1jb250ZW50OmNlbnRlcjtcclxuICAgIGZsZXgtd3JhcDp3cmFwO1xyXG4gICAgbWFyZ2luLXRvcDogNSU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDE1MHB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDE1MHB4O1xyXG4gICAgbWF4LXdpZHRoOjEwMCU7XHJcbiAgICA+IGEge1xyXG4gICAgICBtYXgtd2lkdGg6MzgwcHg7XHJcbiAgICAgIGhlaWdodDoxODBweDtcclxuICAgICAgbWFyZ2luOjEwcHg7XHJcbiAgICAgIG92ZXJmbG93OmhpZGRlbjtcclxuICAgICAgYm9yZGVyLXJhZGl1czoxNXB4O1xyXG4gICAgICBib3gtc2hhZG93OjAgMCAwIDBweCB3aGl0ZSwgMCA0cHggN3B4IDNweCByZ2JhKGJsYWNrLCAwLjEpO1xyXG4gICAgICBpbWcge1xyXG4gICAgICAgIHRyYW5zZm9ybTpzY2FsZSgxKTtcclxuICAgICAgICB0cmFuc2l0aW9uOnRyYW5zZm9ybSAwLjFzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgIGZpbHRlcjpncmF5c2NhbGUoNTAlKTtcclxuICAgICAgICBtaW4td2lkdGg6MTAwJTtcclxuICAgICAgICBtaW4taGVpZ2h0OjEwMCU7XHJcbiAgICAgICAgbWF4LXdpZHRoOjEwMCU7XHJcbiAgICAgICAgbWF4LWhlaWdodDoxMDAlO1xyXG4gICAgICB9XHJcbiAgICAgICY6aG92ZXIge1xyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICB0cmFuc2Zvcm06c2NhbGUoMS4xKTtcclxuICAgICAgICAgIGZpbHRlcjpncmF5c2NhbGUoMCUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAubGlnaHRib3gge1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIHBvc2l0aW9uOmZpeGVkO1xyXG4gICAgYmFja2dyb3VuZDpyZ2JhKGJsYWNrLDAuNSk7XHJcbiAgICBiYWNrZHJvcC1maWx0ZXI6Ymx1cigxMHB4KTtcclxuICAgIC13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOiBibHVyKDEwcHgpO1xyXG4gICAgaGVpZ2h0OjEwMCU7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgbGVmdDowO1xyXG4gICAgdG9wOjA7XHJcbiAgICB0cmFuc2Zvcm06dHJhbnNsYXRlWSgtMTAwJSk7XHJcbiAgICBvcGFjaXR5OjA7XHJcbiAgICB0cmFuc2l0aW9uOm9wYWNpdHkgMC41cyBlYXNlLWluLW91dDtcclxuICAgICY6aGFzKGRpdjp0YXJnZXQpIHtcclxuICAgICAgdHJhbnNmb3JtOnRyYW5zbGF0ZVkoMCUpO1xyXG4gICAgICBvcGFjaXR5OjE7XHJcbiAgICB9XHJcbiAgICBhLm5hdiB7XHJcbiAgICAgIHRleHQtZGVjb3JhdGlvbjpub25lO1xyXG4gICAgICBjb2xvcjp3aGl0ZTtcclxuICAgICAgZm9udC1zaXplOjQwcHg7XHJcbiAgICAgIHRleHQtc2hhZG93OjAgMnB4IDJweCByZ2JhKGJsYWNrLDAuOCk7XHJcbiAgICAgIG9wYWNpdHk6MC41O1xyXG4gICAgICBmb250LXdlaWdodDoyMDA7XHJcbiAgICAgICY6aG92ZXIge1xyXG4gICAgICAgIG9wYWNpdHk6MTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLnRhcmdldCB7XHJcbiAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgaGVpZ2h0OjEwMCU7XHJcbiAgICAgIHdpZHRoOjkwJTtcclxuICAgICAgZGlzcGxheTpmbGV4O1xyXG4gICAgICB0cmFuc2Zvcm06c2NhbGUoMCk7XHJcbiAgICAgIGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuICAgICAganVzdGlmeS1jb250ZW50OnNwYWNlLWJldHdlZW47XHJcbiAgICAgICo6Zmlyc3QtY2hpbGQsKjpsYXN0LWNoaWxkIHtcclxuICAgICAgICBmbGV4OjAgMCAxMDBweDtcclxuICAgICAgICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICBAbWVkaWEgYWxsIGFuZCAobWF4LXdpZHRoOjYwMHB4KXtcclxuICAgICAgICAgIGZsZXg6MCAwIDUwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5jb250ZW50IHtcclxuICAgICAgICB0cmFuc2Zvcm06c2NhbGUoMC45KTtcclxuICAgICAgICBvcGFjaXR5OjA7XHJcbiAgICAgICAgZmxleDoxIDEgYXV0bztcclxuICAgICAgICBhbGlnbi1zZWxmOiBjZW50ZXI7XHJcbiAgICAgICAgbWF4LWhlaWdodDoxMDAlO1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6MDtcclxuICAgICAgICAvLyBtYXgtd2lkdGg6Y2FsYygxMDAlIC0gMjAwcHgpO1xyXG4gICAgICAgIG1pbi13aWR0aDowO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6MTVweDtcclxuICAgICAgICBvdmVyZmxvdzpoaWRkZW47XHJcbiAgICAgICAgYm94LXNoYWRvdzowIDAgMCAzcHggd2hpdGUsIDAgNXB4IDhweCAzcHggcmdiYShibGFjaywgMC4yKTtcclxuICAgICAgICB0cmFuc2l0aW9uOnRyYW5zZm9ybSAwLjI1cyBlYXNlLWluLW91dCxvcGFjaXR5IDAuMjVzIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgIGltZyB7XHJcbiAgICAgICAgICBtaW4td2lkdGg6MTAwJTtcclxuICAgICAgICAgIG1pbi1oZWlnaHQ6MTAwJTtcclxuICAgICAgICAgIG1heC13aWR0aDoxMDAlO1xyXG4gICAgICAgICAgbWF4LWhlaWdodDpjYWxjKDEwMHZoIC0gNDBweCk7XHJcbiAgICAgICAgICBkaXNwbGF5OmJsb2NrO1xyXG4gICAgICAgICAgbWFyZ2luOjA7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgICY6dGFyZ2V0IHtcclxuICAgICAgICB0cmFuc2Zvcm06c2NhbGUoMSk7XHJcbiAgICAgICAgLmNvbnRlbnQge1xyXG4gICAgICAgICAgdHJhbnNmb3JtOnNjYWxlKDEpO1xyXG4gICAgICAgICAgb3BhY2l0eToxO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmNsb3NlIHtcclxuICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgIHJpZ2h0OjEwcHg7XHJcbiAgICAgIHRvcDoxMHB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcblxyXG4gICAgLmJ1dHRvbiB7XHJcbiAgICBwYWRkaW5nOiA3cHggMTBweDtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICB9XHJcbiAgXHJcbiAgLmJ1dHRvbi1wcmltYXJ5IHtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIGJsYWNrO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweDtcclxuICB9XHJcbiAgXHJcbiAgYS5idXR0b24tcHJpbWFyeTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjNDQ0O1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICBcclxuICBhLmJ1dHRvbi1wcmltYXJ5OmhvdmVyIC5zd2l0Y2gtZm9udDpiZWZvcmUge1xyXG4gICAgIGNvbnRlbnQ6IFwiXFxmMTE5XCI7XHJcbiAgfSBcclxuICBcclxuICBhLmJ1dHRvbi1zZWNvbmRhcnk6aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogIzQ0NDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHJlZDtcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgXHJcbiAgLmJ1dHRvbi1zZWNvbmRhcnkge1xyXG4gICAgYmFja2dyb3VuZDogYmxhY2s7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIC5zd2l0Y2gtZm9udDpiZWZvcmUge1xyXG4gICAgY29udGVudDogXCJcXGYwMDdcIjtcclxuICB9ICJdfQ== */";

/***/ }),

/***/ 4050:
/*!******************************************************!*\
  !*** ./src/app/gallery/gallery.page.html?ngResource ***!
  \******************************************************/
/***/ ((module) => {

module.exports = "<ion-content  overflow-scroll=\"false\" >\n<div class=\"thumbs\">\n  \n  <a href=\"#target1\"><img src='https://golestankooh.com/apppictures/abi/1.jpg' alt=''></a>\n  <a href=\"#target2\"><img src='https://golestankooh.com/apppictures/abi/2.JPG' alt=''></a>\n  <a href=\"#target3\"><img src='https://golestankooh.com/apppictures/abi/3.JPG' alt=''></a>\n  <a href=\"#target4\"><img src='https://golestankooh.com/apppictures/abi/4.JPG' alt=''></a>\n  <a href=\"#target5\"><img src='https://golestankooh.com/apppictures/abi/5.JPG' alt=''></a>\n  <a href=\"#target6\"><img src='https://golestankooh.com/apppictures/abi/6.jpg' alt=''></a>\n  <a href=\"#target7\"><img src='https://golestankooh.com/apppictures/abi/7.jpg' alt=''></a>\n  <a href=\"#target8\"><img src='https://golestankooh.com/apppictures/abi/8.JPG' alt=''></a>\n  <a href=\"#target9\"><img src='https://golestankooh.com/apppictures/abi/9.jpg' alt=''></a>\n  <a href=\"#target10\"><img src='https://golestankooh.com/apppictures/abi/10.jpg' alt=''></a>\n  <a href=\"#target11\"><img src='https://golestankooh.com/apppictures/abi/11.jpg' alt=''></a>\n  <a href=\"#target12\"><img src='https://golestankooh.com/apppictures/abi/12.jpg' alt=''></a>\n\n\n  <a href=\"#target15\"><img src='https://golestankooh.com/apppictures/nabere/1.jpg' alt=''></a>\n  <a href=\"#target16\"><img src='https://golestankooh.com/apppictures/nabere/2.jpg' alt=''></a>\n  <a href=\"#target17\"><img src='https://golestankooh.com/apppictures/nabere/3.jpg' alt=''></a>\n  <a href=\"#target18\"><img src='https://golestankooh.com/apppictures/nabere/4.jpg' alt=''></a>\n  <a href=\"#target19\"><img src='https://golestankooh.com/apppictures/suits/1.jpg' alt=''></a>\n  <a href=\"#target20\"><img src='https://golestankooh.com/apppictures/suits/2.jpg' alt=''></a>\n  <a href=\"#target21\"><img src='https://golestankooh.com/apppictures/suits/3.jpg' alt=''></a>\n  <a href=\"#target22\"><img src='https://golestankooh.com/apppictures/suits/4.jpg' alt=''></a>\n  <a href=\"#target23\"><img src='https://golestankooh.com/apppictures/suits/5.jpg' alt=''></a>\n  <a href=\"#target24\"><img src='https://golestankooh.com/apppictures/suits/6.jpg' alt=''></a>\n  <a href=\"#target25\"><img src='https://golestankooh.com/apppictures/karvansara/1a.jpg' alt=''></a>\n  <a href=\"#target26\"><img src='https://golestankooh.com/apppictures/karvansara/2a.jpg' alt=''></a>\n  <a href=\"#target27\"><img src='https://golestankooh.com/apppictures/karvansara/3a.jpg' alt=''></a>\n  <a href=\"#target28\"><img src='https://golestankooh.com/apppictures/karvansara/1.jpg' alt=''></a>\n  <a href=\"#target29\"><img src='https://golestankooh.com/apppictures/karvansara/2.jpg' alt=''></a>\n  <a href=\"#target30\"><img src='https://golestankooh.com/apppictures/talar/1.JPG' alt=''></a>\n  <a href=\"#target31\"><img src='https://golestankooh.com/apppictures/talar/2.JPG' alt=''></a>\n\n\n\n\n</div>\n\n<div class=\"lightbox\">\n  <div class=\"target\" id=\"target1\">\n    <div class=\"content\">\n      <img src='https://golestankooh.com/apppictures/abi/1.jpg' alt=''>\n    </div>\n    <a href=\"#target2\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target2\">\n    <a href=\"#target1\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/2.JPG\" alt=''></div>\n    <a href=\"#target3\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target3\">\n    <a href=\"#target2\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\"><img src='https://golestankooh.com/apppictures/abi/3.JPG' alt=''></div>\n    <a href=\"#target4\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target4\">\n    <a href=\"#target3\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/4.JPG\" alt=''></div>\n    <a href=\"#target5\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target5\">\n    <a href=\"#target4\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/5.JPG\" alt=''></div>\n    <a href=\"#target6\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target6\">\n    <a href=\"#target5\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/6.jpg\" alt=''></div>\n    <a href=\"#target7\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target7\">\n    <a href=\"#target6\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/7.jpg\" alt=''></div>\n    <a href=\"#target8\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target8\">\n    <a href=\"#target7\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/8.JPG\" alt=''></div>\n    <a href=\"#target9\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target11\">\n    <a href=\"#target8\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/11.jpg\" alt=''></div>\n    <a href=\"#target10\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target10\">\n    <a href=\"#target11\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/abi/10.jpg\" alt=''></div>\n      <a href=\"#target10\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n\n\n\n\n  <div class=\"target\" id=\"target15\">\n    <a href=\"#target10\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/nabere/1.jpg\" alt=''></div>\n      <a href=\"#target16\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>  \n  <div class=\"target\" id=\"target16\">\n    <a href=\"#target15\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/nabere/2.jpg\" alt=''></div>\n      <a href=\"#target17\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>  \n  <div class=\"target\" id=\"target17\">\n    <a href=\"#target16\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/nabere/3.jpg\" alt=''></div>\n      <a href=\"#target18\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target18\">\n    <a href=\"#target17\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/nabere/4.jpg\" alt=''></div>\n      <a href=\"#target19\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target19\">\n    <a href=\"#target18\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/suits/1.jpg\" alt=''></div>\n      <a href=\"#target20\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target20\">\n    <a href=\"#target19\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/suits/2.jpg\" alt=''></div>\n      <a href=\"#target21\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target21\">\n    <a href=\"#target20\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/suits/3.jpg\" alt=''></div>\n      <a href=\"#target22\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target22\">\n    <a href=\"#target21\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/suits/4.jpg\" alt=''></div>\n      <a href=\"#target23\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target23\">\n    <a href=\"#target22\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/suits/5.jpg\" alt=''></div>\n      <a href=\"#target24\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n    <div class=\"target\" id=\"target24\">\n    <a href=\"#target23\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/suits/6.jpg\" alt=''></div>\n      <a href=\"#target25\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target25\">\n    <a href=\"#target24\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/karvansara/1a.jpg\" alt=''></div>\n      <a href=\"#target26\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target26\">\n    <a href=\"#target25\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/karvansara/2a.jpg\" alt=''></div>\n      <a href=\"#target27\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target27\">\n    <a href=\"#target26\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/karvansara/3a.jpg\" alt=''></div>\n      <a href=\"#target28\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target28\">\n    <a href=\"#target27\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/karvansara/1.jpg\" alt=''></div>\n      <a href=\"#target29\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target29\">\n    <a href=\"#target28\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/talar/2.JPG\" alt=''></div>\n      <a href=\"#target30\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target30\">\n    <a href=\"#target29\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/talar/1.JPG\" alt=''></div>\n      <a href=\"#target31\" class=\"fas fa-chevron-right nav\" title=\"next\"></a>\n  </div>\n  <div class=\"target\" id=\"target31\">\n    <a href=\"#target30\" class=\"fas fa-chevron-left nav\" title=\"previous\"></a>\n    <div class=\"content\">\n      <img src=\"https://golestankooh.com/apppictures/talar/2.JPG\" alt=''></div>\n  </div>\n  \n  <a href=\"#!\" class=\"fas fa-times close nav\"></a>\n</div>";

/***/ })

}]);
//# sourceMappingURL=src_app_gallery_gallery_module_ts.js.map