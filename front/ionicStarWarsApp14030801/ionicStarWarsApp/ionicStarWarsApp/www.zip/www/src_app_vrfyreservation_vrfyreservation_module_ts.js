"use strict";
(self["webpackChunkapp"] = self["webpackChunkapp"] || []).push([["src_app_vrfyreservation_vrfyreservation_module_ts"],{

/***/ 99819:
/*!*******************************************************************!*\
  !*** ./src/app/vrfyreservation/vrfyreservation-routing.module.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VrfyreservationPageRoutingModule": () => (/* binding */ VrfyreservationPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var _vrfyreservation_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vrfyreservation.page */ 23766);




const routes = [
    {
        path: '',
        component: _vrfyreservation_page__WEBPACK_IMPORTED_MODULE_0__.VrfyreservationPage
    }
];
let VrfyreservationPageRoutingModule = class VrfyreservationPageRoutingModule {
};
VrfyreservationPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], VrfyreservationPageRoutingModule);



/***/ }),

/***/ 41495:
/*!***********************************************************!*\
  !*** ./src/app/vrfyreservation/vrfyreservation.module.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VrfyreservationPageModule": () => (/* binding */ VrfyreservationPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 94666);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 2508);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 93819);
/* harmony import */ var _vrfyreservation_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vrfyreservation-routing.module */ 99819);
/* harmony import */ var _vrfyreservation_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vrfyreservation.page */ 23766);







let VrfyreservationPageModule = class VrfyreservationPageModule {
};
VrfyreservationPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _vrfyreservation_routing_module__WEBPACK_IMPORTED_MODULE_0__.VrfyreservationPageRoutingModule
        ],
        declarations: [_vrfyreservation_page__WEBPACK_IMPORTED_MODULE_1__.VrfyreservationPage]
    })
], VrfyreservationPageModule);



/***/ }),

/***/ 23766:
/*!*********************************************************!*\
  !*** ./src/app/vrfyreservation/vrfyreservation.page.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "VrfyreservationPage": () => (/* binding */ VrfyreservationPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 34929);
/* harmony import */ var _vrfyreservation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vrfyreservation.page.html?ngResource */ 39819);
/* harmony import */ var _vrfyreservation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./vrfyreservation.page.scss?ngResource */ 46926);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ 58987);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 22560);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 60124);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ 44661);
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ 92340);








let VrfyreservationPage = class VrfyreservationPage {
    constructor(http, route, router) {
        this.has_vocher = false;
        this.http = http;
        this.route = route;
        this.route.queryParams.subscribe(params => {
            this.mid = params["MID"];
            this.ref_num = params["RefNum"];
            this.res_num = params["ResNum"];
            this.status = params["Status"];
        });
    }
    ngOnInit() {
        this.model = {};
        if (this.status == 2) {
            let params = new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpParams();
            params = params.set('ResNum', this.res_num);
            params = params.set('RefNum', this.ref_num);
            params = params.set('MID', this.mid);
            params = params.set('api_key', `${src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.host.api_key}`);
            let httpOptions = {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpHeaders().set('Content-Type', 'application/x-www-form-urlencoded')
            };
            this.show();
            this.http.post(src_environments_environment__WEBPACK_IMPORTED_MODULE_2__.environment.host.apiurl + "/Api/Verifyreservation", params, httpOptions)
                .pipe((0,rxjs_operators__WEBPACK_IMPORTED_MODULE_4__.finalize)(() => this.hide()))
                .subscribe(res => {
                this.model = res.result.result;
                if (this.model.isPaid == true && res.result.docno > 0) {
                    this.has_vocher = true;
                    this.vocher_link = res.result.vocher_link;
                    this.msg = "شماره پذیرش شما" + res.result.docno + " می باشد";
                }
            }, error => console.error(error));
        }
        else {
            this.model.isPaid = false;
            this.model.message = this.Get_Message(this.status);
        }
    }
    openwin() {
        window.open(this.vocher_link);
    }
    Get_Message(status) {
        let message = "";
        switch (status?.toString()) {
            case "1":
                message = "کاربر انصراف داده است";
                break;
            case "2":
                message = "پرداخت با موفقیت انجام شد.";
                break;
            case "3":
                message = "پرداخت انجام نشد";
                break;
            case "4":
                message = "کاربر در بازه زمانی تعیین شده پاسخی ارسال نکرده است.";
                break;
            case "5":
                message = "پارامترهای ارسالی نامعتبر است.";
                break;
            case "8":
                message = "آدرس سرور پذیرنده نامعتبر است ";
                break;
            case "10":
                message = "توکن ارسال شده یافت نشد.";
                break;
            case "11":
                message = " این شماره ترمینال فقط تراکنش های توکنی قابل پرداخت هستند.";
                break;
            case "12":
                message = "شماره ترمینال ارسال شده یافت نشد";
                break;
            default:
                message = "خطایی نا مشخص";
                break;
        }
        return message;
    }
    show() {
        const backdropWrapperElement = this.createLoadingBackdropTemplate();
        const bodyElement = document.querySelector('body');
        bodyElement?.appendChild(backdropWrapperElement);
    }
    hide() {
        const backdropWrapperElement = document.querySelector('#loadingBackdrop');
        backdropWrapperElement?.remove();
    }
    createLoadingBackdropTemplate() {
        const element = document.createElement('div');
        element.setAttribute('id', 'loadingBackdrop');
        element.setAttribute('style', `
      width: 100vw;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      position: absolute;
      top: 0;
      z-index: 999;
      background:radial-gradient(rgb(126 128 136), transparent);
    `);
        element.innerHTML = `
      <div class="backdrop"></div>
      <div class="spinner"> در حال دریافت اطلاعات
        <div></div>
        <div></div>
        <div></div>
        <div></div>
      </div>
    `;
        return element;
    }
};
VrfyreservationPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__.HttpClient },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.ActivatedRoute },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router }
];
VrfyreservationPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_5__.RouterLink],
        selector: 'app-vrfyreservation',
        template: _vrfyreservation_page_html_ngResource__WEBPACK_IMPORTED_MODULE_0__,
        styles: [_vrfyreservation_page_scss_ngResource__WEBPACK_IMPORTED_MODULE_1__]
    })
], VrfyreservationPage);



/***/ }),

/***/ 46926:
/*!**********************************************************************!*\
  !*** ./src/app/vrfyreservation/vrfyreservation.page.scss?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "@font-face {\r\n     font-family: 'B Homa';\r\n     src: url('B Homa_p30download.com.ttf');\r\n     font-style: normal;\r\n     font-weight: 400;\r\n     font-display: swap;\r\n   }\r\n   @font-face {\r\n    font-family: 'Ray';\r\n    font-style: normal;\r\n    font-weight: normal;\r\n    src: url('Ray.ttf');\r\n  }\r\n   @font-face {\r\n    font-family: 'Ray-Bold';\r\n    font-style: normal;\r\n    font-weight: normal;\r\n    src: url('Ray-Bold.ttf');\r\n    \r\n  }\r\n   .ion_title {\n  text-align: right;\n  direction: rtl;\n  font-family: \"B Homa\";\n  background-color: azure;\n}\r\n   ion-content {\n  text-align: center;\n  font-family: \"B Homa\";\n}\r\n   .btn {\n  text-align: center;\n  font-family: \"B Homa\";\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uL3RoZW1lL2ZvbnQuY3NzIiwidnJmeXJlc2VydmF0aW9uLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtLQUNLLHFCQUFxQjtLQUNyQixzQ0FBc0Q7S0FDdEQsa0JBQWtCO0tBQ2xCLGdCQUFnQjtLQUNoQixrQkFBa0I7R0FDcEI7R0FDQTtJQUNDLGtCQUFrQjtJQUNsQixrQkFBa0I7SUFDbEIsbUJBQW1CO0lBQ25CLG1CQUFtQztFQUNyQztHQUNBO0lBQ0UsdUJBQXVCO0lBQ3ZCLGtCQUFrQjtJQUNsQixtQkFBbUI7SUFDbkIsd0JBQXdDOztFQUUxQztHQ2xCRjtFQUNJLGlCQUFBO0VBQ0EsY0FBQTtFQUNBLHFCQUFBO0VBQ0EsdUJBQUE7QUFDSjtHQUNBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtBQUVKO0dBQUE7RUFDSSxrQkFBQTtFQUNBLHFCQUFBO0FBR0oiLCJmaWxlIjoidnJmeXJlc2VydmF0aW9uLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBmb250LWZhY2Uge1xyXG4gICAgIGZvbnQtZmFtaWx5OiAnQiBIb21hJztcclxuICAgICBzcmM6IHVybCgnLi4vYXNzZXRzL2ZvbnRzL0IgSG9tYV9wMzBkb3dubG9hZC5jb20udHRmJyk7XHJcbiAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgZm9udC1kaXNwbGF5OiBzd2FwO1xyXG4gICB9XHJcbiAgIEBmb250LWZhY2Uge1xyXG4gICAgZm9udC1mYW1pbHk6ICdSYXknO1xyXG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICAgIHNyYzogdXJsKCcuLi9hc3NldHMvZm9udHMvUmF5LnR0ZicpO1xyXG4gIH1cclxuICBAZm9udC1mYWNlIHtcclxuICAgIGZvbnQtZmFtaWx5OiAnUmF5LUJvbGQnO1xyXG4gICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICAgIHNyYzogdXJsKCcuLi9hc3NldHMvZm9udHMvUmF5LUJvbGQudHRmJyk7XHJcbiAgICBcclxuICB9IiwiQGltcG9ydCB1cmwoLi4vLi4vdGhlbWUvZm9udC5jc3MpO1xyXG4uaW9uX3RpdGxle1xyXG4gICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICBkaXJlY3Rpb246IHJ0bDtcclxuICAgIGZvbnQtZmFtaWx5OiAnQiBIb21hJztcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGF6dXJlO1xyXG59XHJcbmlvbi1jb250ZW50e1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZm9udC1mYW1pbHk6ICdCIEhvbWEnO1xyXG59XHJcbi5idG57XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LWZhbWlseTogJ0IgSG9tYSc7IFxyXG59XHJcbiJdfQ== */";

/***/ }),

/***/ 39819:
/*!**********************************************************************!*\
  !*** ./src/app/vrfyreservation/vrfyreservation.page.html?ngResource ***!
  \**********************************************************************/
/***/ ((module) => {

module.exports = "<ion-header>\n  <ion-toolbar>\n    <ion-title class=\"ion_title\">نتیجه پرداخت در درگاه الکترونیک:</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div>\n    {{model.message}}\n\n  </div>\n  <div>\n    {{msg}}\n  </div>\n  <div Ngif=\"has_vocher==12\">\n   \n    <a style=\"cursor: pointer;color: blue;\" onclick=\"window.open('https://golestankooh.com/data/test.pdf')\"> \n      از طریق این لینک  می توانید وچر خود را دانلود کنید\n    </a>\n \n  </div>\n\n  <ion-button class=\"btn\" onclick=\"location.href='https://golestankooh.com/#/reserve'\">\n\n    بازگشت به صفحه اصلی\n  </ion-button>\n</ion-content>";

/***/ })

}]);
//# sourceMappingURL=src_app_vrfyreservation_vrfyreservation_module_ts.js.map